package com.cloud_factory.demo;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloud_factory.system.Entity.User.User;
import com.cloud_factory.system.mappers.User.UserMapper;
import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;
import java.util.Map;

@SpringBootTest
@RequiredArgsConstructor
class DemoApplicationTests {
	@Resource
	private final UserMapper userMapper;

	@Test
	void contextLoads() {

	}

}
