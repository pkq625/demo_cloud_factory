const constant_map = {
    "fuId":"用户ID",
    "fuName":"用户姓名",
    "fuPsw":"用户密码",
    "fuRname":"用户真实姓名",
    "fuTypeId":"用户类别",
    "gmtModified":"修改时间",
    "gmtCreate":"创建时间",
    "gmtCreated":"创建时间",
    "ffId":"工厂ID",
    "ffOid":"负责人ID",
    "ffName":"工厂名称",
    "ffState":"工厂状态",
    "furiId":"信息ID",
    "furiUid":"用户ID",
    "furiPhone":"联系方式",
    "furiAddr":"收货地址",
    "ffacilityId":"设备ID",
    "ffCode":"设备编号",
    "ffacilityName":"设备名字",
    "ffLength":"设备长",
    "ffWidth":"设备宽",
    "ffHeight":"设备高",
    "ffTypeId":"设备类型ID",
    "ffInfo":"设备信息",
    "fftId":"设备类型ID",
    "fpId":"产品ID",
    "fpCode":"产品编号",
    "fpName":"产品名称",
    "fpTypeId":"产品类型",
    "fpLength":"产品长",
    "fpWitdth":"产品宽",
    "fpHeight":"产品高",
    "fpInfo":"产品信息",
    "fptId":"产品类别ID",
    "fptName":"产品类别名称",
    "fptPid":"产品父类别名称",
    "fmoId":"订单ID",
    "fmoCode":"订单编号",
    "fmoUriId":"订单收货人信息ID",
    "fmoUid":"订单收货人ID",
    "fmoState":"订单状态",
    "fmoFinishDay":"订单截止日期",
    "fmoBidFinishDay":"订单交付日期",
    "fmoPid":"所需产品ID",
    "fmoPnum":"产品需求量",

    "fgaFid":"工厂ID",
    "fgaPid":"产品ID",
    "fgaGnumPb":"产量",

    "fbId":"竞标ID",
    "fbFid":"竞标工厂ID",
    "fbState":"竞标状态",
    "fbFinishTime":"竞标截止日期",
    "fbBidPrice":"竞标价格",
    "fbNum":"竞标数量",
    "fbOid":"竞标订单ID",

    "fsId":"排产ID",
    "fsFactoryId":"排产工厂ID",
    "fsFacilityId":"排产设备ID",
    "fsFoid":"排产工厂订单ID",
    "fsStartDay":"排产开始日期",
    "fsEndDay":"排产结束日期",

    "srlId":"租借ID",
    "srlFactoryId":"租借工厂ID",
    "srlFacilityId":"租借设备ID",
    "srlMsg":"租借信息",
    "srlStartDay":"租借开始日期",
    "srlEndDay":"租借结束日期",
}

async function newTable($, url){
    // url是json文件的所在网址
    let cols = [[{type: "checkbox", width: 50}]]
    var needOwnerInfo = false;
    var needTime = false;
    var needOpt = false;
    var needChangeFacilityType = false;
    let t;
    let res;
    await $.getJSON(url, function (data){
        console.log(data)
        res = data
        t = data[0]
        console.log(t)
    })
    let map_t = _objToStrMap(t)
    let temp_arr = Array.from(map_t.keys())
    console.log(temp_arr)
    if (temp_arr[0] == "ffacilityId"){
        needChangeFacilityType = true
    }
    if (temp_arr[0] != "fuId" && temp_arr[0] != "furiId" && temp_arr[0] != "ffacilityId" &&
        temp_arr[0] != "fftId"&& temp_arr[0] != "fpId" && temp_arr[0] != "fptId" && temp_arr[0] != "fmoId"
        && temp_arr[0] != "fgaFid" && temp_arr[0] != "fbId" && temp_arr[0] != "srlId" && temp_arr[0] != "fsId"
    ){
        needOwnerInfo = true;
    }
    if (temp_arr[0] == "fuId"){
        needTime = true;
    }
    if (temp_arr[0]!="furiId"){
        needOpt = true
    }
    for (let i = 0; i < temp_arr.length; i++){
        if (temp_arr[i] == "deleted"){
            continue
        }
        let template_map = {
            field:"",
            title:"",
            sort:true
        }
        console.log(temp_arr[i])
        if (needTime){
            template_map.field = temp_arr[i]
            template_map.title = constant_map[temp_arr[i]]
        }else{
            if (temp_arr[i].indexOf("gmt") !== -1){
                continue
            }else{
                template_map.field = temp_arr[i]
                template_map.title = constant_map[temp_arr[i]]
            }
        }
        cols[0].push(template_map)
    }
    if (needOpt)
        cols[0].push({title: '操作', minWidth: 150, toolbar: '#currentTableBar', align: "center"})
    if (needChangeFacilityType)
        cols[0].push({title: '修改', minWidth: 150, toolbar: '#currentTableBar2', align: "center"})
    if (needOwnerInfo)
        cols[0].push({title: '负责人信息', minWidth: 150, toolbar: '#currentTableBar2', align: "center"})
    console.log(cols)
    return [cols, res]
}

function _objToStrMap(obj){
    let strMap = new Map();
    for (let k of Object.keys(obj)) {
        strMap.set(k,obj[k]);
    }
    return strMap;
}