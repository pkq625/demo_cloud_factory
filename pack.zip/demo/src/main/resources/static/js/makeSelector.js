//获取商品的【状态信息】，绑定到Select下拉框上
async function GetAudit_status($, elem, url, type) {
    await $.ajax({
        url: url,
        type: type,
        success: function (data) {
            if (data !== "" && data != null) {
                console.log(data)
                var opa=document.createElement("option");  //新建option
                opa.setAttribute("value","");  // 设置value
                opa.appendChild(document.createTextNode(""));  //text
                elem.appendChild(opa);  // 为select添加option
                for (var i = 0; i < data.length; i++) {
                    var op=document.createElement("option");  //新建option
                    op.setAttribute("value",data[i].fuId);  // 设置value
                    op.appendChild(document.createTextNode(data[i].fuName));  //text
                    elem.appendChild(op);  // 为select添加option
                }
            }
        }
    })
}
async function GetAudit_status2($, elem, url, type) {
    await $.ajax({
        url: url,
        type: type,
        success: function (data) {
            if (data !== "" && data != null) {
                console.log(data)
                var opa=document.createElement("option");  //新建option
                opa.setAttribute("value","");  // 设置value
                opa.appendChild(document.createTextNode(""));  //text
                elem.appendChild(opa);  // 为select添加option
                for (var i = 0; i < data.length; i++) {
                    var op=document.createElement("option");  //新建option
                    op.setAttribute("value",data[i].fftId);  // 设置value
                    op.appendChild(document.createTextNode(data[i].fftName));  //text
                    elem.appendChild(op);  // 为select添加option
                }
            }
        }
    })
}

async function GetAudit_status3($, elem, url, type) {
    await $.ajax({
        url: url,
        type: type,
        success: function (data) {
            if (data !== "" && data != null) {
                console.log(data)
                var opa=document.createElement("option");  //新建option
                opa.setAttribute("value","");  // 设置value
                opa.appendChild(document.createTextNode(""));  //text
                elem.appendChild(opa);  // 为select添加option
                for (var i = 0; i < data.length; i++) {
                    var op=document.createElement("option");  //新建option
                    op.setAttribute("value",data[i].ffacilityId);  // 设置value
                    op.appendChild(document.createTextNode(data[i].ffacilityName));  //text
                    elem.appendChild(op);  // 为select添加option
                }
            }
        }
    })
}

async function GetAudit_status4($, elem, url, type, selectedItem) {
    await $.ajax({
        url: url,
        type: type,
        success: function (data) {
            if (data !== "" && data != null) {
                console.log(data)
                var opa=document.createElement("option");  //新建option
                opa.setAttribute("value","");  // 设置value
                opa.appendChild(document.createTextNode(""));  //text
                elem.appendChild(opa);  // 为select添加option
                for (var i = 0; i < data.length; i++) {
                    var op=document.createElement("option");  //新建option
                    op.setAttribute("value",data[i].fptId);  // 设置value
                    op.appendChild(document.createTextNode(data[i].fptName));  //text
                    console.log(selectedItem)
                    if (data[i].fptId == selectedItem){
                        op.selected = true
                    }
                    elem.appendChild(op);  // 为select添加option
                }
            }
        }
    })
}

async function GetAudit_status5($, elem, url, type) {
    await $.ajax({
        url: url,
        type: type,
        success: function (data) {
            if (data !== "" && data != null) {
                console.log(data)
                for (var i = 0; i < data.length; i++) {
                    var op=document.createElement("option");  //新建option
                    op.setAttribute("value",data[i].fptId);  // 设置value
                    op.appendChild(document.createTextNode(data[i].fptName));  //text
                    elem.appendChild(op);  // 为select添加option
                }
            }
        }
    })
}

async function GetAudit_status6($, elem, url, type, selectedItem, value) {
    await $.ajax({
        url: url,
        type: type,
        success: function (data) {
            if (data !== "" && data != null) {
                console.log(data)

                var opa=document.createElement("option");  //新建option
                opa.setAttribute("value","");  // 设置value
                opa.appendChild(document.createTextNode(""));  //text
                elem.appendChild(opa);  // 为select添加option
                console.log(value)
                console.log(selectedItem)

                for (var i = 0; i < data.length; i++) {
                    if (value == data[i].fptId){
                        continue
                    }
                    var op=document.createElement("option");  //新建option
                    op.setAttribute("value",data[i].fptId);  // 设置value
                    op.appendChild(document.createTextNode(data[i].fptName));  //text
                    if (data[i].fptId == selectedItem){
                        op.selected = true
                    }
                    elem.appendChild(op);  // 为select添加option
                }
            }
        }
    })
}

async function GetAudit_status7($, elem, url, type) {
    await $.ajax({
        url: url,
        type: type,
        success: function (data) {
            if (data !== "" && data != null) {
                console.log(data)
                var opa=document.createElement("option");  //新建option
                opa.setAttribute("value","");  // 设置value
                opa.appendChild(document.createTextNode(""));  //text
                elem.appendChild(opa);  // 为select添加option
                for (var i = 0; i < data.length; i++) {
                    var op=document.createElement("option");  //新建option
                    op.setAttribute("value",data[i].fpId);  // 设置value
                    op.appendChild(document.createTextNode(data[i].fpName));  //text
                    elem.appendChild(op);  // 为select添加option
                }
            }
        }
    })
}

async function GetAudit_status8($, elem, url, type, item) {
    await $.ajax({
        url: url,
        type: type,
        success: function (data) {
            if (data !== "" && data != null) {
                console.log(data)
                var opa=document.createElement("option");  //新建option
                opa.setAttribute("value","");  // 设置value
                opa.appendChild(document.createTextNode(""));  //text
                elem.appendChild(opa);  // 为select添加option
                for (var i = 0; i < data.length; i++) {
                    var op=document.createElement("option");  //新建option
                    op.setAttribute("value",data[i].ffacilityId);  // 设置value
                    op.appendChild(document.createTextNode(data[i].ffacilityName));  //text
                    if (data[i].ffId == item){
                        op.selected = true
                    }
                    elem.appendChild(op);  // 为select添加option
                }
            }
        }
    })
}

async function GetAudit_status9($, elem, url, type, item) {
    await $.ajax({
        url: url,
        type: type,
        success: function (data) {
            if (data !== "" && data != null) {
                console.log(data)
                var opa=document.createElement("option");  //新建option
                opa.setAttribute("value","");  // 设置value
                opa.appendChild(document.createTextNode(""));  //text
                elem.appendChild(opa);  // 为select添加option
                for (var i = 0; i < data.length; i++) {
                    var op=document.createElement("option");  //新建option
                    op.setAttribute("value",data[i].fpId);  // 设置value
                    op.appendChild(document.createTextNode(data[i].fpName));  //text
                    if (data[i].fpId == item){
                        op.selected = true
                    }
                    elem.appendChild(op);  // 为select添加option
                }
            }
        }
    })
}
async function GetAudit_status10($, elem, url, type, item) {
    await $.ajax({
        url: url,
        type: type,
        success: function (data) {
            if (data !== "" && data != null) {
                console.log(data)
                var opa=document.createElement("option");  //新建option
                opa.setAttribute("value","");  // 设置value
                opa.appendChild(document.createTextNode(""));  //text
                elem.appendChild(opa);  // 为select添加option
                for (var i = 0; i < data.length; i++) {
                    var op=document.createElement("option");  //新建option
                    op.setAttribute("value",data[i].fuName);  // 设置value
                    op.appendChild(document.createTextNode(data[i].fuName));  //text
                    if (data[i].fuId == item){
                        op.selected = true
                        elem.disabled = "disabled"
                    }
                    elem.appendChild(op);  // 为select添加option
                }
            }
        }
    })
}