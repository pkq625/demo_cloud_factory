package com.cloud_factory.system.Service.Interf.Bid;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud_factory.system.Entity.Bid.FBidWinEntity;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
public interface FBidWinService extends IService<FBidWinEntity> {

}
