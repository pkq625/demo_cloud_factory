package com.cloud_factory.system.Service.Interf.Rent;

import com.cloud_factory.system.Entity.Rent.SysRentLogEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
public interface SysRentLogService extends IService<SysRentLogEntity> {
    void refresh_sys_rent_log();
}
