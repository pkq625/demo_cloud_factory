package com.cloud_factory.system.Service.Impl.Order;

import com.cloud_factory.system.Entity.Order.FMorderEntity;
import com.cloud_factory.system.Service.Interf.Order.FMorderService;
import com.cloud_factory.system.mappers.Order.FMorderMapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FMorderServiceImpl extends ServiceImpl<FMorderMapper, FMorderEntity> implements FMorderService {
    @Resource
    private final FMorderMapper fMorderMapper;

    @Override
    public void createOrder(Map<String, Object> param) {
        fMorderMapper.createOrder(param);
    }

    @Override
    public void pickBid(Map<String, Object> param) {
        fMorderMapper.pickBid(param);
    }

}
