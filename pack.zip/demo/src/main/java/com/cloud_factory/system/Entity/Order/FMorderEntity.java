package com.cloud_factory.system.Entity.Order;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * <p>
 * 
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_morder")
public class FMorderEntity extends Model<FMorderEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "fmo_id", type = IdType.AUTO)
    private Long fmoId;

    @TableField("fmo_code")
    private String fmoCode;

    @TableField("fmo_uri_id")
    private Long fmoUriId;

    @TableField("fmo_uid")
    private Long fmoUid;

    @TableField("fmo_state")
    private String fmoState;

    @TableField("fmo_finish_day")
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private LocalDate fmoFinishDay;

    @TableField("fmo_bid_finish_day")
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private LocalDate fmoBidFinishDay;

    @TableField("fmo_pid")
    private Long fmoPid;

    @TableField("fmo_pnum")
    private Long fmoPnum;

    @TableField(value = "gmt_created", fill= FieldFill.INSERT)
    private LocalDateTime gmtCreated;

    @TableField(value = "gmt_modified", fill= FieldFill.INSERT_UPDATE)
    private LocalDateTime gmtModified;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;


    @Override
    protected Serializable pkVal() {
        return this.fmoId;
    }

}
