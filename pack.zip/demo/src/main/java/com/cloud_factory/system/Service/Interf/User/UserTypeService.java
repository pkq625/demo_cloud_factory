package com.cloud_factory.system.Service.Interf.User;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud_factory.system.Entity.User.UserType;
import org.springframework.stereotype.Service;


/**
 */
@Service
public interface UserTypeService extends IService<UserType> {
    String getTypeName(Long tid);
}
