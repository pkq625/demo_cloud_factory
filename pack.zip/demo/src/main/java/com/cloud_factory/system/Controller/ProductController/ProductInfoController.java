package com.cloud_factory.system.Controller.ProductController;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloud_factory.common.myTreeStructure.myNode;
import com.cloud_factory.common.utils.TypeTree;
import com.cloud_factory.system.Entity.Product.FProductEntity;
import com.cloud_factory.system.Entity.Product.FProductTypeEntity;
import com.cloud_factory.system.Service.Interf.Product.FProductService;
import com.cloud_factory.system.Service.Interf.Product.FProductTypeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

@Controller
@RequiredArgsConstructor
public class ProductInfoController {
    @Resource
    private final FProductService fProductService;
    @Resource
    private final FProductTypeService fProductTypeService;

    @RequestMapping("/system/product/add")
    public String addProduct(){
        return "/system/productInfo/addProduct";
    }

    @RequestMapping("/system/product/getProductTypes")
    @ResponseBody
    public List<FProductTypeEntity> getProductTypes(){
        return fProductTypeService.list();
    }

    @RequestMapping("/system/product/edit")
    public String editProduct(@RequestParam("pid")String pid, Model model){
        model.addAttribute("product", fProductService.getById(Long.parseLong(pid)));
        return "/system/productInfo/editProduct";
    }

    @RequestMapping("/system/product/checkEdit")
    public String checkEdit(HttpServletRequest request, HttpSession session, RedirectAttributesModelMap model){
        FProductEntity e = fProductService.getById(Long.parseLong(request.getParameter("pid")));
        e.setFpCode(request.getParameter("pcode"));
        e.setFpName(request.getParameter("p_name"));
        e.setFpTypeId(Long.parseLong(request.getParameter("ptypeid")));
        e.setFpLength(Long.parseLong(request.getParameter("plength")));
        e.setFpWitdth(Long.parseLong(request.getParameter("pwidth")));
        e.setFpHeight(Long.parseLong(request.getParameter("pheight")));
        e.setFpInfo(request.getParameter("pinfo"));
        fProductService.updateById(e);
        model.addFlashAttribute("msg","修改成功");
        return "redirect:/system/product/edit?pid="+request.getParameter("pid");
    }

    @RequestMapping("/system/product/checkAdd")
    public String checkAdd(HttpServletRequest request, HttpSession session, RedirectAttributesModelMap model){
        FProductEntity e = new FProductEntity();
        if (!request.getParameter("pid").equals("")){
            e.setFpId(Long.parseLong(request.getParameter("pid")));
        }
        e.setFpCode(request.getParameter("pcode"));
        e.setFpName(request.getParameter("p_name"));
        e.setFpTypeId(Long.parseLong(request.getParameter("ptypeid")));
        e.setFpLength(Long.parseLong(request.getParameter("plength")));
        e.setFpWitdth(Long.parseLong(request.getParameter("pwidth")));
        e.setFpHeight(Long.parseLong(request.getParameter("pheight")));
        e.setFpInfo(request.getParameter("pinfo"));
        boolean b = fProductService.save(e);
        if(b){
            model.addFlashAttribute("msg", "添加成功");
        }else{
            model.addFlashAttribute("msg", "添加失败");
        }
        return "redirect:/system/product/add";
    }

    @RequestMapping("/system/product/allProducts")
    @ResponseBody
    public List<FProductEntity> getAllProducts(){
        return fProductService.list();
    }

    @RequestMapping("/system/product/delete")
    @ResponseBody
    public String deleteProducts(@RequestParam("pid")Long pid){
        try {
            fProductService.removeById(pid);
            return "删除成功";
        }catch (Exception e){
            return "删除失败";
        }
    }

    @RequestMapping("/system/product/deleteMore")
    @ResponseBody
    public String deleteMoreProducts(@RequestParam("list")List<Long>list){
        try {
            fProductService.removeByIds(list);
            return "删除成功";
        }catch (Exception e){
            return "删除失败";
        }
    }

    @RequestMapping("/system/product/search")
    @ResponseBody
    public List<FProductEntity> search(@RequestParam("pcode")String pcode, @RequestParam("ptype")String ptype){
        QueryWrapper<FProductEntity> wrapper = new QueryWrapper<>();
        List<FProductEntity> tempList = new ArrayList<>();
        if (!pcode.equals("")){
            System.out.println("?");
            wrapper.like("fp_code",pcode);
            tempList.addAll(fProductService.list(wrapper));
        }

        String typeName = fProductTypeService.getById(ptype).getFptName();

        myNode<String> node = TypeTree.getProductTypeTree().bfs(typeName);
        wrapper.eq("fp_type_id", Long.parseLong(ptype));

        tempList.addAll(fProductService.list(wrapper));
        if (node.getChildNodes()!=null){
            for (myNode<String>e : node.getChildNodes()){
                if (e!=null) {
                    QueryWrapper<FProductEntity> tempQ = new QueryWrapper<>();
                    tempQ.eq("fp_type_id", e.getId());
                    tempList.addAll(fProductService.list(tempQ));
                }
            }
        }

        HashSet<FProductEntity> h = new HashSet<>(tempList);
        tempList.clear();
        tempList.addAll(h);
        return tempList;
    }

}
