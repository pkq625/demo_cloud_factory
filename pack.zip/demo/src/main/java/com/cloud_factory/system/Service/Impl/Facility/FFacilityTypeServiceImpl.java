package com.cloud_factory.system.Service.Impl.Facility;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Facility.FFacilityTypeEntity;
import com.cloud_factory.system.Service.Interf.Facility.FFacilityTypeService;
import com.cloud_factory.system.mappers.Facility.FFacilityTypeMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 * @since 2021-07-14
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FFacilityTypeServiceImpl extends ServiceImpl<FFacilityTypeMapper, FFacilityTypeEntity> implements FFacilityTypeService {
    @Resource
    private final FFacilityTypeMapper fFacilityTypeMapper;
}