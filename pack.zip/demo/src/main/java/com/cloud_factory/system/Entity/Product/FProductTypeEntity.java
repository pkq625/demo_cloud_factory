package com.cloud_factory.system.Entity.Product;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_product_type")
public class FProductTypeEntity extends Model<FProductTypeEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "fpt_id", type = IdType.AUTO)
    private Long fptId;

    @TableField("fpt_name")
    private String fptName;

    @TableField("fpt_pid")
    private Long fptPid;


    @Override
    protected Serializable pkVal() {
        return this.fptId;
    }

}
