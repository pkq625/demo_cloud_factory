package com.cloud_factory.system.Service.Interf.Order;

import com.cloud_factory.system.Entity.Order.FForderEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
public interface FForderService extends IService<FForderEntity> {

}
