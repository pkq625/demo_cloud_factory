package com.cloud_factory.system.Controller.OrderController;

import com.cloud_factory.system.Entity.Order.FForderEntity;
import com.cloud_factory.system.Service.Interf.Order.FForderService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class FactoryOrderController {
    @Resource
    private final FForderService forderService;

    @RequestMapping("/system/factorOrder/getAllOrder")
    @ResponseBody
    public List<FForderEntity> getAllOrder(){
        return forderService.list();
    }
}
