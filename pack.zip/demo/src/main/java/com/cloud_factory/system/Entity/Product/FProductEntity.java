package com.cloud_factory.system.Entity.Product;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_product")
public class FProductEntity extends Model<FProductEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "fp_id", type = IdType.AUTO)
    private Long fpId;

    @TableField("fp_code")
    private String fpCode;

    @TableField("fp_name")
    private String fpName;

    @TableField("fp_type_id")
    private Long fpTypeId;

    @TableField("fp_length")
    private Long fpLength;

    @TableField("fp_witdth")
    private Long fpWitdth;

    @TableField("fp_height")
    private Long fpHeight;

    @TableField("fp_info")
    private String fpInfo;

    @TableField(value = "gmt_create", fill=FieldFill.INSERT)
    private LocalDateTime gmtCreate;

    @TableField(value = "gmt_modified", fill= FieldFill.INSERT_UPDATE)
    private LocalDateTime gmtModified;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;


    @Override
    protected Serializable pkVal() {
        return this.fpId;
    }

}
