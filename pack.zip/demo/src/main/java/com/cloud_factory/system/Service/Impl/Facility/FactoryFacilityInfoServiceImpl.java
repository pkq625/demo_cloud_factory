package com.cloud_factory.system.Service.Impl.Facility;

import com.cloud_factory.system.Entity.Facility.FactoryFacilityInfoEntity;
import com.cloud_factory.system.Service.Interf.Facility.FactoryFacilityInfoService;
import com.cloud_factory.system.mappers.Facility.FactoryFacilityInfoMapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * VIEW 服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FactoryFacilityInfoServiceImpl extends ServiceImpl<FactoryFacilityInfoMapper, FactoryFacilityInfoEntity> implements FactoryFacilityInfoService {
    @Resource
    private final FactoryFacilityInfoMapper factoryFacilityInfoMapper;
}
