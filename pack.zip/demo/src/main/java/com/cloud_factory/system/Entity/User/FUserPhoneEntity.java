package com.cloud_factory.system.Entity.User;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author Tery
 * @since 2021-07-14
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_user_phone")
public class FUserPhoneEntity extends Model<FUserPhoneEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "fup_uid", type = IdType.AUTO)
    private Long fupUid;

    @TableField("fup_phonenum")
    private String fupPhonenum;


    @Override
    protected Serializable pkVal() {
        return this.fupUid;
    }

}
