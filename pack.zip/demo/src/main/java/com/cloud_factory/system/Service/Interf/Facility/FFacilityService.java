package com.cloud_factory.system.Service.Interf.Facility;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud_factory.system.Entity.Facility.FFacilityEntity;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @since 2021-07-14
 */

public interface FFacilityService extends IService<FFacilityEntity> {
    void addFacility(Map<String, Object> param);
    void shtDownOrOpen(Map<String, Object> param);
}
