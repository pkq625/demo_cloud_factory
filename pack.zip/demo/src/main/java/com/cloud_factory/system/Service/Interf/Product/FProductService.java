package com.cloud_factory.system.Service.Interf.Product;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud_factory.system.Entity.Product.FProductEntity;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
public interface FProductService extends IService<FProductEntity> {

}
