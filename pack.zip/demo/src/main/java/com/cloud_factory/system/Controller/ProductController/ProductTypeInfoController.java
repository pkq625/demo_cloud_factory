package com.cloud_factory.system.Controller.ProductController;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloud_factory.common.myTreeStructure.myNode;
import com.cloud_factory.common.myTreeStructure.myTree;
import com.cloud_factory.common.utils.TypeTree;
import com.cloud_factory.system.Entity.Product.FProductTypeEntity;
import com.cloud_factory.system.Service.Interf.Product.FProductTypeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.*;

@Controller
@RequiredArgsConstructor
public class ProductTypeInfoController {
    @Resource
    private final FProductTypeService productTypeService;

    @RequestMapping("/system/productType/delete")
    @ResponseBody
    public String delete(@RequestParam("typeId")Long typeId){
        boolean b = productTypeService.removeById(typeId);
        if (b)
            return "删除成功";
        else
            return "删除失败";
    }

    @RequestMapping("/system/productType/deleteMore")
    @ResponseBody
    public String deleteMore(@RequestParam("List")List<Long>list){
        boolean b = productTypeService.removeByIds(list);
        if (b)
            return "删除成功";
        else
            return "删除失败";
    }

    @RequestMapping("/system/productType/checkAdd")
    @ResponseBody
    public String checkAdd(@RequestParam("typeId")String typeId, @RequestParam("typeName")String typeName, @RequestParam("parentTypeId")String parentTypeId){
        FProductTypeEntity e = new FProductTypeEntity();
        if (!typeId.equals("")){
            e.setFptId(Long.parseLong(typeId));
        }
        e.setFptPid(Long.parseLong(parentTypeId));
        e.setFptName(typeName);
        boolean b = productTypeService.save(e);
        if (b)
            return "添加成功";
        else
            return "添加失败";
    }

    @RequestMapping("/system/productType/add")
    public String add(){
        return "/system/productTypeInfo/addProductType";
    }

    @RequestMapping("/system/productType/checkEdit")
    @ResponseBody
    public String checkEdit(@RequestParam("typeId")String typeId, @RequestParam("typeName")String typeName, @RequestParam("parentTypeId")String parentTypeId){
        FProductTypeEntity e = productTypeService.getById(Long.parseLong(typeId));

        e.setFptPid(Long.parseLong(parentTypeId));
        e.setFptName(typeName);
        boolean b = productTypeService.updateById(e);
        if (b)
            return "修改成功";
        else
            return "修改失败";
    }

    @RequestMapping("/system/productType/edit")
    public String edit(@RequestParam("typeId")String typeId, Model model){
        FProductTypeEntity e = productTypeService.getById(Long.parseLong(typeId));
        model.addAttribute("typeId",e.getFptId());
        model.addAttribute("typeName",e.getFptName());
        model.addAttribute("parentTypeId",e.getFptPid());
        return "/system/productTypeInfo/editProductType";
    }

    @RequestMapping("initProductTypeTree")
    @ResponseBody
    public String initTree(){
        QueryWrapper<FProductTypeEntity> wrapper = new QueryWrapper<>();
        wrapper.eq("fpt_name", "商品");
        FProductTypeEntity rootNode = productTypeService.getOne(wrapper);
        TypeTree.setProductTypeTree(new myTree<>(rootNode.getFptId(), rootNode.getFptName()));
        List<Map<String, Object>> childrenNodes = productTypeService.getChildren();
        for (Map<String, Object> map : childrenNodes){
            TypeTree.getProductTypeTree().addNode(Long.parseLong(String.valueOf(map.get("childId"))), String.valueOf(map.get("childInfo")), String.valueOf(map.get("parentInfo")));
        }
        return "初始化成功";
    }

    @RequestMapping("/system/productType/getAllProductType")
    @ResponseBody
    public List<FProductTypeEntity> productTypeInfo(){
        return productTypeService.list();
    }

    @RequestMapping("/system/productType/search")
    @ResponseBody
    public List<FProductTypeEntity> search(@RequestParam("typeId")String typeId){
        QueryWrapper<FProductTypeEntity>wrapper = new QueryWrapper<>();
        if (!typeId.equals("")){
            wrapper.eq("fpt_id", Long.parseLong(typeId));
        }
        return productTypeService.list(wrapper);
    }

    @RequestMapping("/system/productType/searchWithChildren")
    @ResponseBody
    public List<FProductTypeEntity> searchWithChildren(@RequestParam("typeId")String typeId){
        QueryWrapper<FProductTypeEntity>wrapper = new QueryWrapper<>();
        List<FProductTypeEntity> list = new ArrayList<>();
        if (!typeId.equals("")){
            wrapper.eq("fpt_id", Long.parseLong(typeId));

            String name = productTypeService.getById(Long.parseLong(typeId)).getFptName();
            myNode<String> node = TypeTree.getProductTypeTree().bfs(name);

            if (node.getChildNodes()!=null){
                for (myNode<String>e : node.getChildNodes()){
                    if (e!=null) {
                        QueryWrapper<FProductTypeEntity> tempQ = new QueryWrapper<>();
                        tempQ.eq("fpt_id", e.getId());
                        list.addAll(productTypeService.list(tempQ));
                    }
                }
            }
        }
        list.addAll(productTypeService.list(wrapper));

        HashSet<FProductTypeEntity> h = new HashSet<>(list);
        list.clear();
        list.addAll(h);

        return list;
    }

    @RequestMapping("getNode")
    @ResponseBody
    public String getNode(@RequestParam("curName")String curName){
        if (null == TypeTree.getProductTypeTree()){
            return "先初始化产品类型树";
        }
        myNode<String> node = TypeTree.getProductTypeTree().bfs(curName);
        return node.getInfo();
    }
    @RequestMapping("getParentNode")
    @ResponseBody
    public String getParentNode(@RequestParam("curName")String curName){
        if (null == TypeTree.getProductTypeTree()){
            return "先初始化产品类型树";
        }
        myNode<String> node = TypeTree.getProductTypeTree().bfs(curName);
        return node.getParentNode().getInfo();
    }

    @RequestMapping("getChildrenNode")
    @ResponseBody
    public List<String> getChildrenNode(@RequestParam("curName")String curName){
        myNode<String> node = TypeTree.getProductTypeTree().bfs(curName);
        List<String>res = new ArrayList<>();
        for (myNode<String>nodeInfo: node.getChildNodes()){
            res.add(nodeInfo.getInfo());
        }
        return res;
    }
}
