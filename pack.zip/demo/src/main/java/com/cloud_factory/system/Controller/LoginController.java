package com.cloud_factory.system.Controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class LoginController {
    @Resource
    private RedisTemplate redisTemplate;

    @RequestMapping(value = "/checkLogin", method = RequestMethod.POST)
    public String checkLogin(HttpServletRequest request, HttpSession session, RedirectAttributesModelMap model){
        String captcha = request.getParameter("captcha");

        String uuid = session.getAttribute("CaptchaCode").toString();
        Object code=redisTemplate.opsForValue().get(uuid);

        System.out.println("获得验证码为："+code);

        if(code!=null){
            code = code.toString();
            if (!captcha.equals(code)){
                System.out.println("验证码错误");
                model.addFlashAttribute("msg", "验证码错误");
            }else{
                String username = request.getParameter("username");
                String password = request.getParameter("password");

                // 获取当前用户
                Subject subject = SecurityUtils.getSubject();
                // 封装用户的登录数据
                UsernamePasswordToken token = new UsernamePasswordToken(username, password);
                try{
                    subject.login(token);// 执行登录方法，如果没有异常就ok
                    System.out.println("success");
                    model.addFlashAttribute("msg", "登录成功");

                    return "redirect:/index";
                } catch (UnknownAccountException e){// 用户名不存在
                    System.out.println("用户名不存在");
                    model.addFlashAttribute("msg", "用户名不存在");
                }catch (IncorrectCredentialsException e){ //密码错误
                    System.out.println("密码错误");
                    model.addFlashAttribute("msg", "密码错误");
                }
                String checked = request.getParameter("checked");
            }
        }else{
            System.out.println("验证码已过期！");
            model.addFlashAttribute("msg", "验证码已过期");
        }
        return "redirect:/login";
    }
}
