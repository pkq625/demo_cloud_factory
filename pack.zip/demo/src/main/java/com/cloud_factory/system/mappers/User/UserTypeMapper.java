package com.cloud_factory.system.mappers.User;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud_factory.system.Entity.User.UserType;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserTypeMapper extends BaseMapper<UserType> {
    String getTypeName(Long tid);
}
