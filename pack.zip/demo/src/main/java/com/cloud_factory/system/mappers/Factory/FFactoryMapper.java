package com.cloud_factory.system.mappers.Factory;

import com.cloud_factory.system.Entity.Factory.FFactoryEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Tery
 * @since 2021-07-14
 */
@Mapper
public interface FFactoryMapper extends BaseMapper<FFactoryEntity> {

}
