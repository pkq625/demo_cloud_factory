package com.cloud_factory.system.Entity.Factory;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Tery
 * @since 2021-07-14
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_factory")
public class FFactoryEntity extends Model<FFactoryEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "ff_id", type = IdType.AUTO)
    private Long ffId;

    @TableField("ff_oid")
    private Long ffOid;

    @TableField("ff_name")
    private String ffName;

    @TableField("ff_state")
    private String ffState;

    @TableField("ff_info")
    private String ffInfo;

    @TableField(value = "gmt_created", fill= FieldFill.INSERT)
    private LocalDateTime gmtCreated;

    @TableField(value = "gmt_modified", fill= FieldFill.INSERT_UPDATE)
    private LocalDateTime gmtModified;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;


    @Override
    protected Serializable pkVal() {
        return this.ffId;
    }

}
