package com.cloud_factory.system.Controller.FacilityController;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

import com.cloud_factory.common.utils.convertBeans;
import com.cloud_factory.system.Entity.Facility.*;
import com.cloud_factory.system.Entity.Factory.FFactoryEntity;
import com.cloud_factory.system.Service.Interf.Facility.*;
import com.cloud_factory.system.Service.Interf.Factory.FFactoryService;
import com.cloud_factory.system.Service.Interf.User.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class facilityInfoController {
    @Resource
    private final FFacilityService fFacilityService;
    @Resource
    private final FFacilityTypeService fFacilityTypeService;
    @Resource
    private final FactoryFacilityInfoService factoryFacilityInfoService;
    @Resource
    private final PlatformFacilityInfoService platformFacilityInfoService;
    @Resource
    private final UserService userService;
    @Resource
    private final FFactoryService fFactoryService;
    @Resource
    private final FFfacilityService fFfacilityService;

    @RequestMapping("/system/facility/getFacilityTypes")
    @ResponseBody
    public List<FFacilityTypeEntity> getFacilityTypes(){
        return fFacilityTypeService.list();
    }


    @RequestMapping("/system/facility/getFactoryOwnerFacility")
    @ResponseBody
    public List<FFacilityEntity> getFactoryOwnerFacility(@RequestParam("uid")Long uid){
        QueryWrapper<FFactoryEntity>q1 = new QueryWrapper<>();
        q1.eq("fu_id", uid);
        List<FFactoryEntity> factories = fFactoryService.list(q1);

        List<FFacilityEntity>res = new ArrayList<>();

        for (FFactoryEntity e : factories){
            QueryWrapper<FFfacilityEntity>q2 = new QueryWrapper<>();
            q2.eq("fff_fid",e.getFfId());
            List<FFfacilityEntity> factory_facilities = fFfacilityService.list(q2);
            for (FFfacilityEntity te: factory_facilities){
                QueryWrapper<FFacilityEntity> q3 = new QueryWrapper<>();
                q3.eq("ffacility_id", te.getFffId());
                res.addAll(fFacilityService.list(q3));
            }
        }

        return res;
    }

    @RequestMapping("/system/facility/getFacility")
    @ResponseBody
    public List<FFacilityEntity> getFacility(){
        return fFacilityService.list();
    }

    @RequestMapping("/system/facility/checkChangeType")
    @ResponseBody
    public Map<String, Object> checkChangeType(@RequestParam("fid") Long fid, @RequestParam("newTypeId")Long newTypeId){
        FFacilityEntity e = fFacilityService.getById(fid);
        e.setFfTypeId(newTypeId);
        boolean b = fFacilityService.updateById(e);
        Map<String, Object> res = new HashMap<>();
        if (b){
            res.put("msg", "修改成功");
        }else{
            res.put("msg","修改失败");
        }
        return res;
    }

    @RequestMapping("/system/facility/changeType")
    public String changeType(@RequestParam("fid")Long fid,@RequestParam("fid")Long ftypeid, Model model){
        model.addAttribute("fid", fid);
        model.addAttribute("ftype",fFacilityTypeService.getById(ftypeid).getFftName());

        return "/system/facilityInfo/ChangeFacilityType";
    }

    @RequestMapping("/system/facility/changeState")
    public String changeState(@RequestParam("fid")Long fid, Model model){
        model.addAttribute("fid", fid);
        return "/system/facilityInfo/changeFacilityState";
    }

    @RequestMapping("/system/facility/open")
    @ResponseBody
    public Map<String, Object> Open(@RequestParam("fid")Long fid, @RequestParam("ok")String ok){
        Map<String, Object> res = new HashMap<>();
        if (ok.equals("可以")){
            Map<String, Object> param = new HashMap<>();
            param.put("fid",fid);
            param.put("changeTo","开机");
            param.put("result","");
            fFacilityService.shtDownOrOpen(param);
            if (String.valueOf(param.get("result")).contains("成功")) {
                res.put("msg", "开机成功");
            }else{
                res.put("msg", "开机失败");
            }
        }else{
            res.put("msg", "开机失败");
        }

        return res;
    }

    @RequestMapping("/system/facility/shutDown")
    @ResponseBody
    public Map<String, Object> shutDown(@RequestParam("fid")Long fid, @RequestParam("ok")String ok){
        Map<String, Object> res = new HashMap<>();
        if (ok.equals("可以")){
            Map<String, Object> param = new HashMap<>();
            param.put("fid",fid);
            param.put("changeTo","关机");
            param.put("result","");
            fFacilityService.shtDownOrOpen(param);
            if (String.valueOf(param.get("result")).contains("成功")) {
                res.put("msg", "关机成功");
            }else{
                res.put("msg", "关机失败");
            }
        }else{
            res.put("msg", "关机失败");
        }

        return res;
    }

    @RequestMapping("/system/facility/getState")
    @ResponseBody
    public Map<String, Object> getState(@RequestParam("fid")Long fid){
        QueryWrapper<PlatformFacilityInfoEntity> wrapper1 = new QueryWrapper<>();
        wrapper1.eq("fpf_id",fid);
        PlatformFacilityInfoEntity e1 = platformFacilityInfoService.getOne(wrapper1);

        QueryWrapper<FactoryFacilityInfoEntity> wrapper2 = new QueryWrapper<>();
        wrapper2.eq("fff_id", fid);
        FactoryFacilityInfoEntity e2 = factoryFacilityInfoService.getOne(wrapper2);

        Map<String, Object> res = new HashMap<>();

        if (null == e2){ // 如果当前设备不在工厂中,那它必然是供租用的设备
            if (e1!=null){
                if (!e1.getFpfState().equals("不可用")) { // 如果租用设备可用
                    if (e1.getFpfState().equals("关机")){
                        res.put("fstate", "关机");
                    }else{
                        res.put("fstate", "空闲");
                    }
                    res.put("rstate", e1.getFpfState());
                }else {
                    res.put("fstate", "不可用");
                    res.put("rstate", "不可用");
                }
            }
        }else{
            res.put("fstate", e2.getFffState());
            res.put("rstate","工厂设备");
        }

        return res;
    }

    @RequestMapping("/system/facility/getAllFacility")
    @ResponseBody
    public List<FFacilityEntity> getAllFacility(){
        return fFacilityService.list();
    }

    @RequestMapping("/system/facility/add")
    public String addFacility(){
        return "/system/facilityInfo/addFacility";
    }

    @RequestMapping("/system/facility/checkAdd")
    public String checkAdd(HttpServletRequest request, HttpSession session, RedirectAttributesModelMap model){
        Map<String, Object> facility = new HashMap<>();

        String fsrc = request.getParameter("fsrc");
        if (fsrc.equals("2")){
            facility.put("src","租借");
            facility.put("fid",-1L);
        }else {
            facility.put("src","非租借");
            facility.put("fid",Long.parseLong(request.getParameter("fid")));
        }
        facility.put("fcode",request.getParameter("fcode"));
        facility.put("flength",Long.parseLong(request.getParameter("flength")));
        facility.put("fwidth",Long.parseLong(request.getParameter("fwidth")));
        facility.put("fheight",Long.parseLong(request.getParameter("fheight")));
        facility.put("fname",request.getParameter("fname"));
        facility.put("ftype", Long.parseLong(request.getParameter("ftype")));
        facility.put("finfo",request.getParameter("finfo"));
        facility.put("result,","");

        fFacilityService.addFacility(facility);
        System.out.println(facility.get("result"));
        model.addFlashAttribute("msg", facility.get("result"));

        return "redirect:/system/facility/add";
    }

    @RequestMapping("/system/facility/deleteMore")
    @ResponseBody
    public String deleteMoreFacility(@RequestParam("List")List<Long>list){
        try {
            fFacilityService.removeByIds(list);
            return "删除成功";
        }catch (Exception e){
            return "当前状态不能删除";
        }
    }

    @RequestMapping("/system/facility/delete")
    @ResponseBody
    public String deleteFacility(@RequestParam("fid")Long fid){
        try {
            fFacilityService.removeById(fid);
            return "删除成功";
        }catch (Exception e){
            return "当前状态不能删除";
        }
    }

    @RequestMapping("/system/facility/searchFacilityWithSrc")
    @ResponseBody
    public List<Map<String, Object>> searchFacility(@RequestParam("fcode")String fcode, @RequestParam("ftype")String ftype
            , @RequestParam("fsrc")String fsrc){
        List<Map<String, Object>> list = new ArrayList<>();
        if (fsrc.equals("1")){
            QueryWrapper<FactoryFacilityInfoEntity>wrapper = new QueryWrapper<>();
            if (!ftype.equals("")) {
                wrapper.eq("ff_type_id", Long.parseLong(ftype));
            }
            if (!fcode.equals("")) {
                wrapper.like("ff_code", fcode);
            }
            List<FactoryFacilityInfoEntity> list1 = factoryFacilityInfoService.list(wrapper);
            for (FactoryFacilityInfoEntity e : list1){
                list.add(convertBeans.getC().beanToMap(e));
            }
        }else {
            QueryWrapper<PlatformFacilityInfoEntity>wrapper = new QueryWrapper<>();
            if (!ftype.equals("")) {
                wrapper.eq("ff_type_id", Long.parseLong(ftype));
            }
            if (!fcode.equals("")) {
                wrapper.like("ff_code", fcode);
            }
            List<PlatformFacilityInfoEntity> list1 = platformFacilityInfoService.list(wrapper);
            for (PlatformFacilityInfoEntity e : list1){
                list.add(convertBeans.getC().beanToMap(e));
            }
        }
        return list;
    }

    @RequestMapping("/system/facility/searchFacility")
    @ResponseBody
    public List<FFacilityEntity> searchFacility(@RequestParam("fcode")String fcode, @RequestParam("ftype")String ftype){
        QueryWrapper<FFacilityEntity> wrapper = new QueryWrapper<>();
        if (!ftype.equals("")) {
            wrapper.eq("ff_type_id", Long.parseLong(ftype));
        }
        if (!fcode.equals("")) {
            wrapper.like("ff_code", fcode);
        }
        return fFacilityService.list(wrapper);
    }
}
