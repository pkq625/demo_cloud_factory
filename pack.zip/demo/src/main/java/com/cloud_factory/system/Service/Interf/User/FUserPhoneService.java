package com.cloud_factory.system.Service.Interf.User;

import com.cloud_factory.system.Entity.User.FUserPhoneEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Tery
 * @since 2021-07-14
 */
public interface FUserPhoneService extends IService<FUserPhoneEntity> {

}
