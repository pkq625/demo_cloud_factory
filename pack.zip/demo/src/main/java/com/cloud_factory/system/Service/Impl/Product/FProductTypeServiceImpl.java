package com.cloud_factory.system.Service.Impl.Product;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Product.FProductTypeEntity;
import com.cloud_factory.system.Service.Interf.Product.FProductTypeService;
import com.cloud_factory.system.mappers.Product.FProductTypeMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FProductTypeServiceImpl extends ServiceImpl<FProductTypeMapper, FProductTypeEntity> implements FProductTypeService {
    @Resource
    private final FProductTypeMapper fProductTypeMapper;

    @Override
    public List<Map<String, Object>> getChildren() {
        return fProductTypeMapper.getChildren();
    }
}
