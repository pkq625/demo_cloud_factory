package com.cloud_factory.system.mappers.Product;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud_factory.system.Entity.Product.FProductTypeEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
@Mapper
public interface FProductTypeMapper extends BaseMapper<FProductTypeEntity> {
    List<Map<String, Object>> getChildren();
}
