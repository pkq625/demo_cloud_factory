package com.cloud_factory.system.Controller.GeneratePowerController;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloud_factory.system.Entity.Facility.FFacilityEntity;
import com.cloud_factory.system.Entity.Facility.FFfacilityEntity;
import com.cloud_factory.system.Entity.Factory.FFactoryEntity;
import com.cloud_factory.system.Entity.GeneratePower.FGenAbilityEntity;
import com.cloud_factory.system.Service.Interf.Facility.FFfacilityService;
import com.cloud_factory.system.Service.Interf.Factory.FFactoryService;
import com.cloud_factory.system.Service.Interf.GeneratePower.FGenAbilityService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class GPController {
    @Resource
    private final FGenAbilityService genAbilityService;
    @Resource
    private final FFactoryService fFactoryService;
    @Resource
    private final FFfacilityService fFfacilityService;

    @RequestMapping("/system/generatePower/add")
    public String add(){
        return "/system/generatePowerInfo/add";
    }

    @RequestMapping("/system/generatePower/edit")
    public String edit(@RequestParam("facilityId")Long facilityId, @RequestParam("productId")Long productId, @RequestParam("num")Long num, Model model){
        model.addAttribute("facilityId",facilityId);
        model.addAttribute("productId", productId);
        model.addAttribute("num",num);
        return "/system/generatePowerInfo/edit";
    }

    @RequestMapping("/system/generatePower/allGP")
    @ResponseBody
    public List<FGenAbilityEntity> getAllGP(){
        return genAbilityService.list();
    }

    @RequestMapping("/system/generatePower/checkAdd")
    @ResponseBody
    public String checkAdd(@RequestParam("fid")Long facilityId, @RequestParam("pid")Long productId, @RequestParam("num")Long num){
        Map<String, Object> param = new HashMap<>();
        param.put("facilityId",facilityId);
        param.put("productId", productId);
        param.put("gpd",num);
        param.put("result","");
        genAbilityService.maintainFacility(param);
        return String.valueOf(param.get("result"));
    }

    @RequestMapping("/system/generatePower/checkEdit")
    @ResponseBody
    public String checkEdit(@RequestParam("fid")Long facilityId, @RequestParam("pid")Long productId, @RequestParam("num")Long num){
        Map<String, Object> param = new HashMap<>();
        param.put("facilityId",facilityId);
        param.put("productId", productId);
        param.put("gpd",num);
        param.put("result","");
        genAbilityService.maintainFacility(param);
        return String.valueOf(param.get("result"));
    }

    @RequestMapping("/system/generatePower/delete")
    @ResponseBody
    public String deleteGP(@RequestParam("fid")Long facilityId, @RequestParam("pid")Long productId, @RequestParam("num")Long num){
        QueryWrapper<FGenAbilityEntity> wrapper = new QueryWrapper<>();
        wrapper.eq("fga_fid", facilityId).eq("fga_pid", productId).eq("fga_gnum_pb", num);
        boolean b = genAbilityService.remove(wrapper);
        if (b){
            return "删除成功";
        }else {
            return "删除失败";
        }
    }
    @RequestMapping("/system/generatePower/search")
    @ResponseBody
    public List<FGenAbilityEntity> search(@RequestParam("fid")String facilityId, @RequestParam("pid")String productId){
        QueryWrapper<FGenAbilityEntity>wrapper = new QueryWrapper<>();
        if (!facilityId.equals("")){
            wrapper.eq("fga_fid", facilityId);
        }
        if (!productId.equals("")){
            wrapper.eq("fga_pid", productId);
        }
        return genAbilityService.list(wrapper);
    }
    @RequestMapping("/system/generatePower/generatePower")
    @ResponseBody
    public List<FGenAbilityEntity> generatePower(@RequestParam("uid")Long uid){

        QueryWrapper<FFactoryEntity>q1 = new QueryWrapper<>();
        q1.eq("fu_id", uid);
        List<FFactoryEntity> factories = fFactoryService.list(q1);
        List<FGenAbilityEntity>res = new ArrayList<>();

        for (FFactoryEntity e : factories){
            QueryWrapper<FFfacilityEntity>q2 = new QueryWrapper<>();
            q2.eq("fff_fid",e.getFfId());
            List<FFfacilityEntity> factory_facilities = fFfacilityService.list(q2);
            for (FFfacilityEntity te: factory_facilities){
                QueryWrapper<FGenAbilityEntity> q3 = new QueryWrapper<>();
                q3.eq("fga_fid", te.getFffId());
                res.addAll(genAbilityService.list(q3));
            }
        }

        return res;
    }

}
