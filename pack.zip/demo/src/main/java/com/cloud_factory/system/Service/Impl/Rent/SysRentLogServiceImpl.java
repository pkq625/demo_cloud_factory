package com.cloud_factory.system.Service.Impl.Rent;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Rent.SysRentLogEntity;
import com.cloud_factory.system.Service.Interf.Rent.SysRentLogService;
import com.cloud_factory.system.mappers.Rent.SysRentLogMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class SysRentLogServiceImpl extends ServiceImpl<SysRentLogMapper, SysRentLogEntity> implements SysRentLogService {
    @Resource
    private final SysRentLogMapper sysRentLogMapper;

    @Override
    public void refresh_sys_rent_log() {
        sysRentLogMapper.refresh_sys_rent_log();
    }
}
