package com.cloud_factory.system.Entity.Facility;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("platform_facility_info")
public class PlatformFacilityInfoEntity extends Model<PlatformFacilityInfoEntity> {

    private static final long serialVersionUID = 1L;

    @TableField("ffacility_id")
    private Long ffacilityId;

    @TableField("ff_code")
    private String ffCode;

    @TableField("ffacility_name")
    private String ffacilityName;

    @TableField("ff_length")
    private Long ffLength;

    @TableField("ff_width")
    private Long ffWidth;

    @TableField("ff_height")
    private Long ffHeight;

    @TableField("ff_type_id")
    private Long ffTypeId;

    @TableField("ff_info")
    private String ffInfo;

    @TableField("gmt_modified")
    private LocalDateTime gmtModified;

    @TableField("gmt_created")
    private LocalDateTime gmtCreated;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @TableField("fpf_rentId")
    private Long fpfRentid;

    /**
     * 设备ID
     */
    @TableField("fpf_id")
    private Long fpfId;

    /**
     * 0：可租用，1：租用中，2：过期未归还，3：暂停租用
     */
    @TableField("fpf_state")
    private String fpfState;

    /**
     * 租借工厂ID（可以没有）
     */
    @TableField("fpf_fid")
    private Long fpfFid;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
