package com.cloud_factory.system.Entity.GeneratePower;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_gen_ability")
public class FGenAbilityEntity extends Model<FGenAbilityEntity> {

    private static final long serialVersionUID = 1L;

    @TableField("fga_fid")
    private Long fgaFid;

    @TableField("fga_pid")
    private Long fgaPid;

    @TableField("fga_gnum_pb")
    private Long fgaGnumPb;

    @TableField(value = "gmt_created", fill=FieldFill.INSERT)
    private LocalDateTime gmtCreated;

    @TableField(value = "gmt_modified", fill= FieldFill.INSERT_UPDATE)
    private LocalDateTime gmtModified;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
