package com.cloud_factory.system.Service.Impl.Facility;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Facility.PlatformFacilityInfoEntity;
import com.cloud_factory.system.Service.Interf.Facility.PlatformFacilityInfoService;
import com.cloud_factory.system.mappers.Facility.PlatformFacilityInfoMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * VIEW 服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class PlatformFacilityInfoServiceImpl extends ServiceImpl<PlatformFacilityInfoMapper, PlatformFacilityInfoEntity> implements PlatformFacilityInfoService {
    @Resource
    private final PlatformFacilityInfoMapper platformFacilityInfoMapper;
}
