package com.cloud_factory.system.mappers.Schedule;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud_factory.system.Entity.Schedule.FScheduleEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Mapper
public interface FScheduleMapper extends BaseMapper<FScheduleEntity> {
    void scheduleOrder();
}
