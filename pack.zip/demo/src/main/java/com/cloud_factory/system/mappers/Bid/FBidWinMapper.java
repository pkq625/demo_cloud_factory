package com.cloud_factory.system.mappers.Bid;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud_factory.system.Entity.Bid.FBidWinEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Mapper
public interface FBidWinMapper extends BaseMapper<FBidWinEntity> {

}
