package com.cloud_factory.system.Controller.UserController;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloud_factory.system.Entity.User.User;
import com.cloud_factory.system.Service.Interf.User.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class UserInfoController {
    @Resource
    private final UserService userService;

    @RequestMapping("/system/user/allUsers")
    @ResponseBody
    List<User> getAllUsers(){
        return userService.list();
    }

    @RequestMapping("/system/user/allDeletedUsers")
    @ResponseBody
    List<User> getAllDeletedUsers(){
//        QueryWrapper<User>wrapper = new QueryWrapper<>();
//        wrapper.eq("deleted",1);
        return userService.getDeletedUsers();
    }

    @RequestMapping("/system/user/add")
    public String addUser(){
        return "/system/user/userInfo/addUser";
    }

    @RequestMapping(value = "/system/user/edit", method = RequestMethod.GET)
    public String editUser(@RequestParam("uid") Long uid, Model model){
        System.out.println("打开用户编辑界面");
        User user = userService.getById(uid);
        model.addAttribute("uid", user.getFuId());
        model.addAttribute("uname", user.getFuName());
        model.addAttribute("psw", user.getFuPsw());
        model.addAttribute("rname", user.getFuRname());
        return "/system/user/userInfo/editUser";
    }

    @RequestMapping("/system/user/checkAdd")
    public String checkAdd(HttpServletRequest request, HttpSession session, RedirectAttributesModelMap model){
        Map<String, Object> user = new HashMap<>();
        user.put("uname",request.getParameter("username"));
        user.put("psw",request.getParameter("password"));
        user.put("rname",request.getParameter("truename"));
        user.put("phonenum",request.getParameter("phone"));
        System.out.println(request.getParameter("type"));
        user.put("type", Long.parseLong(request.getParameter("type")));
        String factoryname = "";
        if (!request.getParameter("factoryname").equals("")){
            factoryname = request.getParameter("factoryname");
        }
        user.put("fname",factoryname);
        String finfo = "";
        if (!request.getParameter("factoryinfo").equals("")){
            finfo = request.getParameter("factoryinfo");
        }
        user.put("finfo",finfo);
        user.put("result,","");
        userService.addUser(user);
        System.out.println(user.get("result"));
        model.addFlashAttribute("msg", user.get("result"));
        return "redirect:/system/user/add";
    }

    @RequestMapping("/system/user/checkEdit")
    public String checkEdit(HttpServletRequest request, HttpSession session, RedirectAttributesModelMap model){
        User user = userService.getById(request.getParameter("uid"));
        user.setFuName(request.getParameter("uname"));
        user.setFuPsw(request.getParameter("psw"));
        user.setFuRname(request.getParameter("rname"));
        boolean b = userService.updateById(user);
        if (b){
            model.addFlashAttribute("msg", "修改成功");
        }else {
            model.addFlashAttribute("msg", "修改失败");
        }
        return "redirect:/system/user/edit?uid="+user.getFuId();
    }

    @RequestMapping("/system/user/delete")
    public String deleteUser(@RequestParam("uid")Long uid){
        userService.removeById(uid);
        return "/system/user/userInfo/deleteUser";
    }

    @RequestMapping("/system/user/deleteMore")
    public String deleteMoreUser(@RequestParam("List")List<Long>list){
        userService.removeByIds(list);
        return "/system/user/userInfo/deleteMoreUser";
    }

    @RequestMapping("/system/user/searchUser")
    @ResponseBody
    public List<User> searchUser(@RequestParam("uname")String uname, @RequestParam("utype")String utype){
        QueryWrapper <User> wrapper = new QueryWrapper<>();
        if (!utype.equals(""))
            wrapper.eq("fu_type_id", Long.parseLong(utype));
        if (!uname.equals(""))
            wrapper.like("fu_name", uname);
        return userService.list(wrapper);
    }

    @RequestMapping("/system/user/getFactoryOwners")
    @ResponseBody
    public List<User> getFactoryOwners(){
        QueryWrapper <User> wrapper = new QueryWrapper<>();
        wrapper.eq("fu_type_id", 1L);
        return userService.list(wrapper);
    }
    @RequestMapping("/system/user/allMercantile")
    @ResponseBody
    public List<User> allMercantile(){
        QueryWrapper <User> wrapper = new QueryWrapper<>();
        wrapper.eq("fu_type_id", 2L);
        return userService.list(wrapper);
    }
}
