package com.cloud_factory.system.Service.Interf.Product;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud_factory.system.Entity.Product.FProductTypeEntity;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
public interface FProductTypeService extends IService<FProductTypeEntity> {
    List<Map<String, Object>> getChildren();
}
