package com.cloud_factory.system.Service.Impl.User;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.User.User;
import com.cloud_factory.system.Service.Interf.User.UserService;
import com.cloud_factory.system.mappers.User.UserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 服务接口实现
 *
 * @author tery
 * @since 2021-07-11 22:50:32
 * @description 由 Mybatisplus Code Generator 创建
 */
@Slf4j
@RequiredArgsConstructor
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    @Resource
    private final UserMapper userMapper;

    @Override
    public User findByName(String uname) {
        return baseMapper.findByName(uname);
    }

    @Override
    public void addUser(Map<String, Object> param) {
        userMapper.addUser(param);
    }

    @Override
    public List<User> getDeletedUsers() {
        return userMapper.getDeletedUsers();
    }
}