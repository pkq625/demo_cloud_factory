package com.cloud_factory.system.Service.Impl.Order;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Order.FForderEntity;
import com.cloud_factory.system.Service.Interf.Order.FForderService;
import com.cloud_factory.system.mappers.Order.FForderMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FForderServiceImpl extends ServiceImpl<FForderMapper, FForderEntity> implements FForderService {
    @Resource
    private final FForderMapper fForderMapper;
}
