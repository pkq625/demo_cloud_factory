package com.cloud_factory.system.Service.Impl.User;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.User.UserType;
import com.cloud_factory.system.Service.Interf.User.UserTypeService;
import com.cloud_factory.system.mappers.User.UserTypeMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Slf4j
@RequiredArgsConstructor
@Service
public class UserTypeServiceImpl extends ServiceImpl<UserTypeMapper, UserType> implements UserTypeService {
    @Resource
    UserTypeMapper userTypeMapper;
    @Override
    public String getTypeName(Long tid) {
        return userTypeMapper.getTypeName(tid);
    }
}
