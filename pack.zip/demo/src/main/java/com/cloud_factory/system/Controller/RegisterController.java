package com.cloud_factory.system.Controller;

import com.cloud_factory.system.Service.Interf.User.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@RequiredArgsConstructor
@Controller
public class RegisterController {
    @Resource
    private final UserService userService;

    @RequestMapping(value = "/checkRegister", method = RequestMethod.POST)
    public String toAdd(HttpServletRequest request, HttpSession session, RedirectAttributesModelMap model){
        Map<String, Object> user = new HashMap<>();
        user.put("uname",request.getParameter("username"));
        user.put("psw",request.getParameter("password"));
        user.put("rname",request.getParameter("truename"));
        user.put("phonenum",request.getParameter("phone"));
        System.out.println(request.getParameter("type"));
        user.put("type", Long.parseLong(request.getParameter("type")));
        String factoryname = "";
        if (!request.getParameter("factoryname").equals("")){
            factoryname = request.getParameter("factoryname");
        }
        user.put("fname",factoryname);
        String finfo = "";
        if (!request.getParameter("factoryinfo").equals("")){
            finfo = request.getParameter("factoryinfo");
        }
        user.put("finfo",finfo);
        user.put("result,","");
        userService.addUser(user);
        System.out.println(user.get("result"));
        if (!user.get("result").equals("新增用户成功")){
            model.addFlashAttribute("msg", user.get("result"));
            return "redirect:/register";
        }
        model.addFlashAttribute("uname", request.getParameter("username"));
        model.addFlashAttribute("psw", request.getParameter("password"));
        return "redirect:/login";
    }
}
