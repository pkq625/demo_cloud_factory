package com.cloud_factory.system.Service.Impl.Facility;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Facility.FFacilityEntity;
import com.cloud_factory.system.Service.Interf.Facility.FFacilityService;
import com.cloud_factory.system.mappers.Facility.FFacilityMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @since 2021-07-14
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FFacilityServiceImpl extends ServiceImpl<FFacilityMapper, FFacilityEntity> implements FFacilityService {
    @Resource
    private final FFacilityMapper fFacilityMapper;

    @Override
    public void addFacility(Map<String, Object> param) {
        fFacilityMapper.addFacility(param);
    }

    @Override
    public void shtDownOrOpen(Map<String, Object> param) {
        fFacilityMapper.shtDownOrOpen(param);
    }
}
