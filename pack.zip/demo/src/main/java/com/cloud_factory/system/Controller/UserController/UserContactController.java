package com.cloud_factory.system.Controller.UserController;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloud_factory.system.Entity.User.FUserPhoneEntity;
import com.cloud_factory.system.Service.Interf.User.FUserPhoneService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class UserContactController {
    @Resource
    private final FUserPhoneService userPhoneService;

    @RequestMapping("/system/user/getMoreTelephone")
    @ResponseBody
    public List<FUserPhoneEntity> getMoreInfo(@RequestParam("oid")String uid){
        QueryWrapper<FUserPhoneEntity> wrapper = new QueryWrapper<>();
        wrapper.eq("fup_uid",Long.parseLong(uid));
        return userPhoneService.list(wrapper);
    }
}
