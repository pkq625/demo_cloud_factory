package com.cloud_factory.system.Service.Interf.Facility;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud_factory.system.Entity.Facility.FFfacilityEntity;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @since 2021-07-14
 */
public interface FFfacilityService extends IService<FFfacilityEntity> {

}
