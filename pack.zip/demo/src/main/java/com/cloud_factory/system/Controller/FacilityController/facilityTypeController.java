package com.cloud_factory.system.Controller.FacilityController;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloud_factory.system.Entity.Facility.FFacilityTypeEntity;
import com.cloud_factory.system.Service.Interf.Facility.FFacilityTypeService;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class facilityTypeController {
    @Resource
    private final FFacilityTypeService fFacilityTypeService;

    @RequestMapping("/system/facilityType/edit")
    public String editFacilityType(@RequestParam("typeId")String typeId, @RequestParam("typeName")String typeName, Model model){
        model.addAttribute("typeId", typeId);
        model.addAttribute("typeName", typeName);
        return "/system/facilityTypeInfo/editFacilityType";
    }

    @RequestMapping("/system/facilityType/add")
    public String addFacilityType(){
        return "/system/facilityTypeInfo/addFacilityType";
    }

    @RequestMapping("/system/facilityType/getFacilityTypes")
    @ResponseBody
    public List<FFacilityTypeEntity> getFacilityTypes(){
        return fFacilityTypeService.list();
    }

    @RequestMapping("/system/facilityType/checkAdd")
    @ResponseBody
    public String addFacilityTypes(@RequestParam("typeId")String typeId, @RequestParam("typeName")String typeName){
        FFacilityTypeEntity e = new FFacilityTypeEntity();
        if (!typeId.equals("")) {
            e.setFftId(Long.parseLong(typeId));
        }
        e.setFftName(typeName);
        boolean b = fFacilityTypeService.save(e);
        if (b){
            return "添加成功";
        }else{
            return "添加失败";
        }
    }


    @RequestMapping("/system/facilityType/checkEdit")
    @ResponseBody
    public String editFacilityTypes(@RequestParam("typeId")Long typeId,
                                    @RequestParam("typeName")String typeName){
        FFacilityTypeEntity e = fFacilityTypeService.getById(typeId);
        e.setFftName(typeName);

        fFacilityTypeService.updateById(e);

        return "修改成功";
    }


    @RequestMapping("/system/facilityType/delete")
    @ResponseBody
    public String deleteFacilityTypes(@RequestParam("typeId")Long id){
        try{
            fFacilityTypeService.removeById(id);
            return "删除成功";
        }catch (Exception e){
            return "删除失败";
        }
    }

    @RequestMapping("/system/facilityType/deleteMore")
    @ResponseBody
    public String deleteMoreFacilityTypes(@RequestParam("list")List<Long> ids){
        try{
            fFacilityTypeService.removeByIds(ids);
            return "批量删除成功";
        }catch (Exception e){
            return "批量删除失败";
        }
    }

    @RequestMapping("/system/facilityType/search")
    @ResponseBody
    public List<FFacilityTypeEntity> searchFacilityTypes(@RequestParam("id") String typeName){
        QueryWrapper<FFacilityTypeEntity> wrapper = new QueryWrapper<>();
        if (!typeName.equals("")) {
            wrapper.eq("fft_id", Long.parseLong(typeName));
        }
        return fFacilityTypeService.list(wrapper);
    }
}
