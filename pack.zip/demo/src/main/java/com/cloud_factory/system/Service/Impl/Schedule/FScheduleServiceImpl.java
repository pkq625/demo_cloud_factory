package com.cloud_factory.system.Service.Impl.Schedule;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Schedule.FScheduleEntity;
import com.cloud_factory.system.Service.Interf.Schedule.FScheduleService;
import com.cloud_factory.system.mappers.Schedule.FScheduleMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FScheduleServiceImpl extends ServiceImpl<FScheduleMapper, FScheduleEntity> implements FScheduleService {
    @Resource
    private final FScheduleMapper fScheduleMapper;

    @Override
    public void scheduleOrder() {
        fScheduleMapper.scheduleOrder();
    }
}
