package com.cloud_factory.system.Controller.ScheduleController;

import com.cloud_factory.system.Entity.Schedule.FScheduleEntity;
import com.cloud_factory.system.Service.Interf.Schedule.FScheduleService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class ScheduleController {
    @Resource
    private final FScheduleService fScheduleService;
    @RequestMapping("/system/schedule/FCFS_schedule")
    @ResponseBody
    public List<FScheduleEntity> FCFS_schedule(){
        // 返回排序结果
        fScheduleService.scheduleOrder();
        return fScheduleService.list();
    }

    @RequestMapping("/system/schedule/allSchedule")
    @ResponseBody
    public List<FScheduleEntity> allSchedule(){
        // 返回排序结果
        return fScheduleService.list();
    }

    @RequestMapping("/system/schedule/newSchedules")
    @ResponseBody
    public List<FScheduleEntity> addSchedules(){
        // 返回排序结果
        return fScheduleService.list();
    }

}
