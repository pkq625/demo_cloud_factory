package com.cloud_factory.system.Entity.Facility;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @since 2021-07-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_facility")
public class FFacilityEntity extends Model<FFacilityEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "ffacility_id", type = IdType.AUTO)
    private Long ffacilityId;

    @TableField("ff_code")
    private String ffCode;

    @TableField("ffacility_name")
    private String ffacilityName;

    @TableField("ff_length")
    private Long ffLength;

    @TableField("ff_width")
    private Long ffWidth;

    @TableField("ff_height")
    private Long ffHeight;

    @TableField("ff_type_id")
    private Long ffTypeId;

    @TableField("ff_info")
    private String ffInfo;

    @TableField(value = "gmt_modified", fill= FieldFill.INSERT_UPDATE)
    private LocalDateTime gmtModified;

    @TableField(value = "gmt_created", fill= FieldFill.INSERT)
    private LocalDateTime gmtCreated;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;


    @Override
    protected Serializable pkVal() {
        return this.ffacilityId;
    }

}
