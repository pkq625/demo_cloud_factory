package com.cloud_factory.system.Service.Impl.Facility;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Facility.FFfacilityEntity;
import com.cloud_factory.system.Service.Interf.Facility.FFfacilityService;
import com.cloud_factory.system.mappers.Facility.FFfacilityMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @since 2021-07-14
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FFfacilityServiceImpl extends ServiceImpl<FFfacilityMapper, FFfacilityEntity> implements FFfacilityService {
    @Resource
    private final FFfacilityMapper fFfacilityMapper;
}
