package com.cloud_factory.system.Entity.Facility;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @since 2021-07-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_facility_type")
public class FFacilityTypeEntity extends Model<FFacilityTypeEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "fft_id", type = IdType.AUTO)
    private Long fftId;

    @TableField("fft_name")
    private String fftName;


    @Override
    protected Serializable pkVal() {
        return this.fftId;
    }

}
