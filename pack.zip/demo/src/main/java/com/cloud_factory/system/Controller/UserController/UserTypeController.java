package com.cloud_factory.system.Controller.UserController;

import com.cloud_factory.system.Service.Interf.User.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

@Controller
@RequiredArgsConstructor
public class UserTypeController {
    @Resource
    private final UserService userService;
}
