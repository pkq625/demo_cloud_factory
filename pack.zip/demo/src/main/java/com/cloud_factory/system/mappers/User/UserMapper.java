package com.cloud_factory.system.mappers.User;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud_factory.system.Entity.User.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * (f_user)数据Mapper
 *
 * @author tery
 * @since 2021-07-11 22:50:32
*/
@Mapper
public interface UserMapper extends BaseMapper<User> {
    void addUser(Map<String, Object> param);
    User findByName(String uname);
    String name2psw(String uname);
    List<User> getDeletedUsers();
}
