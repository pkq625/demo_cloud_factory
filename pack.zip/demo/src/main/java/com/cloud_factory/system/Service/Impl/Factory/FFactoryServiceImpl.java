package com.cloud_factory.system.Service.Impl.Factory;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Factory.FFactoryEntity;
import com.cloud_factory.system.Service.Interf.Factory.FFactoryService;
import com.cloud_factory.system.mappers.Factory.FFactoryMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-14
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FFactoryServiceImpl extends ServiceImpl<FFactoryMapper, FFactoryEntity> implements FFactoryService {
    @Resource
    private final FFactoryMapper fFactoryMapper;
}
