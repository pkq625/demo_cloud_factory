package com.cloud_factory.system.Entity.Schedule;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_schedule")
public class FScheduleEntity extends Model<FScheduleEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "fs_id", type = IdType.AUTO)
    private Long fsId;

    @TableField("fs_factory_id")
    private Long fsFactoryId;

    @TableField("fs_facility_id")
    private Long fsFacilityId;

    @TableField("fs_foid")
    private Long fsFoid;

    @TableField("fs_start_day")
    private LocalDate fsStartDay;

    @TableField("fs_end_day")
    private LocalDate fsEndDay;

    @TableField(value = "gmt_created", fill= FieldFill.INSERT)
    private LocalDateTime gmtCreated;

    @TableField(value = "gmt_modified", fill= FieldFill.INSERT_UPDATE)
    private LocalDateTime gmtModified;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;


    @Override
    protected Serializable pkVal() {
        return this.fsId;
    }

}
