package com.cloud_factory.system.Entity.Facility;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("factory_facility_info")
public class FactoryFacilityInfoEntity extends Model<FactoryFacilityInfoEntity> {

    private static final long serialVersionUID = 1L;

    @TableField("ffacility_id")
    private Long ffacilityId;

    @TableField("ff_code")
    private String ffCode;

    @TableField("ffacility_name")
    private String ffacilityName;

    @TableField("ff_length")
    private Long ffLength;

    @TableField("ff_width")
    private Long ffWidth;

    @TableField("ff_height")
    private Long ffHeight;

    @TableField("ff_type_id")
    private Long ffTypeId;

    @TableField("ff_info")
    private String ffInfo;

    @TableField("gmt_modified")
    private LocalDateTime gmtModified;

    @TableField("gmt_created")
    private LocalDateTime gmtCreated;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @TableField("fff_nid")
    private Long fffNid;

    /**
     * 设备ID
     */
    @TableField("fff_id")
    private Long fffId;

    /**
     * 1：空闲，2：忙碌，3：停用
     */
    @TableField("fff_state")
    private String fffState;

    @TableField("fff_src")
    private String fffSrc;

    /**
     * 工厂id
     */
    @TableField("fff_fid")
    private Long fffFid;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
