package com.cloud_factory.system.Controller.UserController;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloud_factory.system.Entity.User.FUreceiveInfoEntity;
import com.cloud_factory.system.Entity.User.FUserPhoneEntity;
import com.cloud_factory.system.Service.Interf.User.FUreceiveInfoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class UserRecieveInfoController {
    @Resource
    private final FUreceiveInfoService fUreceiveInfoService;

    @RequestMapping("/system/user/userReceiveInfo")
    public String userReceiveInfo(@RequestParam("uid")String uid, Model model){
        model.addAttribute("msg", uid);
        return "/system/user/userReceiveInfo/userReceiveInfo";
    }

    @RequestMapping("/system/user/getMoreInfo")
    @ResponseBody
    public List<FUreceiveInfoEntity> getUserReceiveInfo(@RequestParam("uid")String uid){
        QueryWrapper<FUreceiveInfoEntity> wrapper = new QueryWrapper<>();
        wrapper.eq("furi_uid",Long.parseLong(uid));
        return fUreceiveInfoService.list(wrapper);
    }
}
