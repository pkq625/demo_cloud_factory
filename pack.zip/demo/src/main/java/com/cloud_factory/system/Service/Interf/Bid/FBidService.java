package com.cloud_factory.system.Service.Interf.Bid;

import com.cloud_factory.system.Entity.Bid.FBidEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
public interface FBidService extends IService<FBidEntity> {

}
