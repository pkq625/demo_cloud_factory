package com.cloud_factory.system.Entity.Facility;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @since 2021-07-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_pfacility")
public class FPfacilityEntity extends Model<FPfacilityEntity> {

    private static final long serialVersionUID = 1L;

    @TableField("fpf_rentId")
    private Long fpfRentid;

    /**
     * 设备ID
     */
    @TableId(value = "fpf_id", type = IdType.AUTO)
    private Long fpfId;

    /**
     * 0：可租用，1：租用中，2：过期未归还，3：暂停租用
     */
    @TableField("fpf_state")
    private String fpfState;

    /**
     * 租借工厂ID（可以没有）
     */
    @TableField("fpf_fid")
    private Long fpfFid;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @Override
    protected Serializable pkVal() {
        return this.fpfId;
    }

}
