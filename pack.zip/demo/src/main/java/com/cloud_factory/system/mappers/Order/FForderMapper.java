package com.cloud_factory.system.mappers.Order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud_factory.system.Entity.Order.FForderEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Mapper
public interface FForderMapper extends BaseMapper<FForderEntity> {

}
