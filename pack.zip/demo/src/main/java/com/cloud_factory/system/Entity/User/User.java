package com.cloud_factory.system.Entity.User;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * (f_user)实体类
 *
 * @author tery
 * @since 2021-07-11 22:50:32
 * @description 由 Mybatisplus Code Generator 创建
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@Accessors(chain = true)
@TableName("f_user")
public class User extends Model<User> implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * fuId
     */
    @TableId
	private Long fuId;
    /**
     * fuName
     */
    private String fuName;
    /**
     * fuPsw
     */
    private String fuPsw;
    /**
     * fuRname
     */
    private String fuRname;
    /**
     * fuTypeId
     */
    private Long fuTypeId;
    /**
     * fu_gmt_modified
     */
    @TableField(fill=FieldFill.INSERT_UPDATE)
    private Date gmtModified;
    /**
     * fu_gmt_create
     */
    @TableField(fill= FieldFill.INSERT)
    private Date gmtCreate;
    /**
     * deleted
     */
    @TableLogic
    private Integer deleted;
}