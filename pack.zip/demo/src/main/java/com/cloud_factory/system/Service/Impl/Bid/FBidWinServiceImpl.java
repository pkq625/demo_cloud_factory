package com.cloud_factory.system.Service.Impl.Bid;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Bid.FBidWinEntity;
import com.cloud_factory.system.Service.Interf.Bid.FBidWinService;
import com.cloud_factory.system.mappers.Bid.FBidWinMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FBidWinServiceImpl extends ServiceImpl<FBidWinMapper, FBidWinEntity> implements FBidWinService {
    @Resource
    private final FBidWinMapper fBidWinMapper;
}
