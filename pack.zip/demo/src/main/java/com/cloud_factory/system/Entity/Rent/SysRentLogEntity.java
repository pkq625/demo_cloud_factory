package com.cloud_factory.system.Entity.Rent;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDate;
import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sys_rent_log")
public class SysRentLogEntity extends Model<SysRentLogEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "srl_id", type = IdType.AUTO)
    private Long srlId;

    @TableField("srl_factory_id")
    private Long srlFactoryId;

    @TableField("srl_facility_id")
    private Long srlFacilityId;

    @TableField("srl_msg")
    private String srlMsg;

    @TableField("srl_start_day")
    private LocalDate srlStartDay;

    @TableField("srl_end_day")
    private LocalDate srlEndDay;

    @TableField(value = "gmt_created", fill= FieldFill.INSERT)
    private LocalDateTime gmtCreated;

    @TableField(value = "gmt_modified", fill= FieldFill.INSERT_UPDATE)
    private LocalDateTime gmtModified;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @Override
    protected Serializable pkVal() {
        return this.srlId;
    }

}
