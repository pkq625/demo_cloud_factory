package com.cloud_factory.system.Controller.RentController;


import com.cloud_factory.system.Entity.Rent.SysRentLogEntity;
import com.cloud_factory.system.Entity.Schedule.FScheduleEntity;
import com.cloud_factory.system.Service.Interf.Rent.SysRentLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class RentController {
    @Resource
    private final SysRentLogService sysRentLogService;
    @RequestMapping("/system/rent/FCFS_rent")
    @ResponseBody
    public List<SysRentLogEntity> FCFS_rent(){
        // 返回排序结果
        sysRentLogService.refresh_sys_rent_log();
        return sysRentLogService.list();
    }

    @RequestMapping("/system/rent/allRent")
    @ResponseBody
    public List<SysRentLogEntity> allRent(){
        // 返回排序结果
        return sysRentLogService.list();
    }

}
