package com.cloud_factory.system.Entity.Facility;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @since 2021-07-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_ffacility")
public class FFfacilityEntity extends Model<FFfacilityEntity> {

    private static final long serialVersionUID = 1L;

    @TableField("fff_nid")
    private Long fffNid;

    /**
     * 设备ID
     */
    @TableId(value = "fff_id", type = IdType.AUTO)
    private Long fffId;

    /**
     * 1：空闲，2：忙碌，3：停用
     */
    @TableField("fff_state")
    private String fffState;

    @TableField("fff_src")
    private String fffSrc;

    /**
     * 工厂id
     */
    @TableField("fff_fid")
    private Long fffFid;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @Override
    protected Serializable pkVal() {
        return this.fffId;
    }

}
