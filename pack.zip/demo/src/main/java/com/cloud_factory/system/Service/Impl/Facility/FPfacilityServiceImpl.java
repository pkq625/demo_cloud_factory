package com.cloud_factory.system.Service.Impl.Facility;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Facility.FPfacilityEntity;
import com.cloud_factory.system.Service.Interf.Facility.FPfacilityService;
import com.cloud_factory.system.mappers.Facility.FPfacilityMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @since 2021-07-14
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FPfacilityServiceImpl extends ServiceImpl<FPfacilityMapper, FPfacilityEntity> implements FPfacilityService {
    @Resource
    private final FPfacilityMapper fPfacilityMapper;
}
