package com.cloud_factory.system.Service.Interf.Factory;

import com.cloud_factory.system.Entity.Factory.FFactoryEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Tery
 * @since 2021-07-14
 */
public interface FFactoryService extends IService<FFactoryEntity> {

}
