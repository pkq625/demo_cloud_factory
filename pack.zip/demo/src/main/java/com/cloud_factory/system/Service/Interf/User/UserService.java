package com.cloud_factory.system.Service.Interf.User;


import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud_factory.system.Entity.User.User;

import java.util.List;
import java.util.Map;

/**
 * 服务接口
 *
 * @author tery
 * @since 2021-07-11 22:50:32
 */
public interface UserService extends IService<User> {
    User findByName(String uname);
    void addUser(Map<String, Object> param);
    List<User> getDeletedUsers();
}
