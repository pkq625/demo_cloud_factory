package com.cloud_factory.system.Service.Interf.GeneratePower;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud_factory.system.Entity.GeneratePower.FGenAbilityEntity;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
public interface FGenAbilityService extends IService<FGenAbilityEntity> {
    void maintainFacility(Map<String, Object> param);
}
