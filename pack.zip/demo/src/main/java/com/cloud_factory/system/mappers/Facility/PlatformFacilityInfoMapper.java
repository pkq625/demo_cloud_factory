package com.cloud_factory.system.mappers.Facility;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud_factory.system.Entity.Facility.PlatformFacilityInfoEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
@Mapper
public interface PlatformFacilityInfoMapper extends BaseMapper<PlatformFacilityInfoEntity> {

}
