package com.cloud_factory.system.Service.Impl.Product;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Product.FProductEntity;
import com.cloud_factory.system.Service.Interf.Product.FProductService;
import com.cloud_factory.system.mappers.Product.FProductMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-15
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FProductServiceImpl extends ServiceImpl<FProductMapper, FProductEntity> implements FProductService {
    @Resource
    private final FProductMapper fProductMapper;
}
