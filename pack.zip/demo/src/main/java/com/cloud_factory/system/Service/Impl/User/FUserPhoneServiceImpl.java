package com.cloud_factory.system.Service.Impl.User;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.User.FUserPhoneEntity;
import com.cloud_factory.system.Service.Interf.User.FUserPhoneService;
import com.cloud_factory.system.mappers.User.FUserPhoneMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-14
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FUserPhoneServiceImpl extends ServiceImpl<FUserPhoneMapper, FUserPhoneEntity> implements FUserPhoneService {
}
