package com.cloud_factory.system.Service.Interf.Order;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud_factory.system.Entity.Order.FMorderEntity;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
public interface FMorderService extends IService<FMorderEntity> {

    void createOrder(Map<String, Object> param);
    void pickBid(Map<String, Object>param);
}
