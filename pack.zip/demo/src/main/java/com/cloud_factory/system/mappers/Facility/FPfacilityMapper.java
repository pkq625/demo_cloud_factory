package com.cloud_factory.system.mappers.Facility;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud_factory.system.Entity.Facility.FPfacilityEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @since 2021-07-14
 */
@Mapper
public interface FPfacilityMapper extends BaseMapper<FPfacilityEntity> {

}
