package com.cloud_factory.system.Controller;


import cn.apiclub.captcha.Captcha;
import cn.apiclub.captcha.backgrounds.GradiatedBackgroundProducer;
import cn.apiclub.captcha.gimpy.FishEyeGimpyRenderer;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.TimeUnit;


@RestController
@RequestMapping("/captcha")
public class CaptchaController {

    @Resource
    private RedisTemplate<String, String> redisTemplate;

    private final static int captchaExpires = 3*60; //超时时间3min
    private final static int captchaW = 125;
    private final static int captchaH = 45;

    @RequestMapping(value = "/getCaptcha", method = {RequestMethod.GET, RequestMethod.POST})
    public byte[] getCaptcha(HttpServletRequest req, HttpServletResponse response) {
        //生成验证码
        String uuid = UUID.randomUUID().toString();

        Captcha captcha = new Captcha.Builder(captchaW, captchaH)
                .addText().addBackground(new GradiatedBackgroundProducer(Color.orange, Color.white))
                .gimp(new FishEyeGimpyRenderer())
                .build();
        System.out.println("获得新的验证码为: " + captcha.getAnswer());
        //将验证码以<key,value>形式缓存到redis
        redisTemplate.opsForValue().set(uuid, captcha.getAnswer(), captchaExpires, TimeUnit.SECONDS);

        //将验证码key，及验证码的图片返回
        HttpSession session = req.getSession();
        session.setAttribute("CaptchaCode", uuid);

        response.setContentType("image/png");

        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        try {
            System.out.println("加载图片");
            ImageIO.write(captcha.getImage(), "png", bao);
            return bao.toByteArray();
        } catch (IOException e) {
            return null;
        }
    }

}

