package com.cloud_factory.system.Controller.FactoryController;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloud_factory.system.Entity.Factory.FFactoryEntity;
import com.cloud_factory.system.Service.Interf.Factory.FFactoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class FactoryInfoController {
    @Resource
    private final FFactoryService fFactoryService;

    @RequestMapping("/system/factory/allFactory")
    @ResponseBody
    public List<FFactoryEntity> getAllFactory(){
        return fFactoryService.list();
    }

    @RequestMapping("/system/factory/searchFactory")
    @ResponseBody
    public List<FFactoryEntity> searchFactory(@RequestParam("oid")String oid, @RequestParam("fname")String fname){
        QueryWrapper<FFactoryEntity> wrapper = new QueryWrapper<>();
        if (!oid.equals(""))
            wrapper.eq("ff_oid", Long.parseLong(oid));
        if (!fname.equals(""))
            wrapper.like("ff_name", fname);
        return fFactoryService.list(wrapper);
    }

    @RequestMapping("/system/factory/getFactoryOwnerFactory")
    @ResponseBody
    public List<FFactoryEntity> getFactoryOwnerFactory(@RequestParam("uid")String oid){
        QueryWrapper<FFactoryEntity> wrapper = new QueryWrapper<>();
        wrapper.eq("ff_oid", Long.parseLong(oid));
        return fFactoryService.list(wrapper);
    }


    @RequestMapping("/system/factory/changeState")
    public String changeState(@RequestParam("fid")String fid, RedirectAttributesModelMap model){
        FFactoryEntity fFactoryEntity = fFactoryService.getById(Long.parseLong(fid));
        if (fFactoryEntity.getFfState().equals("使用中")){
            fFactoryEntity.setFfState("已停用");
        }else{
            fFactoryEntity.setFfState("使用中");
        }
        fFactoryService.updateById(fFactoryEntity);
        model.addFlashAttribute("msg","修改成功");
        return "redirect:/index#//system/factory/factoryInfo";
    }
}
