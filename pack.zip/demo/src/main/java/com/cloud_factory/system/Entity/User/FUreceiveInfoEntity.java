package com.cloud_factory.system.Entity.User;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.Version;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author Tery
 * @since 2021-07-14
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_ureceive_info")
public class FUreceiveInfoEntity extends Model<FUreceiveInfoEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "furi_id", type = IdType.AUTO)
    private Long furiId;

    @TableField("furi_uid")
    private Long furiUid;

    @TableField("furi_phone")
    private String furiPhone;

    @TableField("furi_addr")
    private String furiAddr;


    @Override
    protected Serializable pkVal() {
        return this.furiId;
    }

}
