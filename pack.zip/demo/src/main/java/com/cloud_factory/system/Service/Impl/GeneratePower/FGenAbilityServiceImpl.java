package com.cloud_factory.system.Service.Impl.GeneratePower;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.GeneratePower.FGenAbilityEntity;
import com.cloud_factory.system.Service.Interf.GeneratePower.FGenAbilityService;
import com.cloud_factory.system.mappers.GeneratePower.FGenAbilityMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FGenAbilityServiceImpl extends ServiceImpl<FGenAbilityMapper, FGenAbilityEntity> implements FGenAbilityService {
    @Resource
    private final FGenAbilityMapper fGenAbilityMapper;

    @Override
    public void maintainFacility(Map<String, Object> param) {
        fGenAbilityMapper.maintainFacility(param);
    }
}
