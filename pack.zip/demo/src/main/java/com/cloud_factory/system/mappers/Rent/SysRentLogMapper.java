package com.cloud_factory.system.mappers.Rent;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud_factory.system.Entity.Rent.SysRentLogEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Mapper
public interface SysRentLogMapper extends BaseMapper<SysRentLogEntity> {
    void refresh_sys_rent_log();
}
