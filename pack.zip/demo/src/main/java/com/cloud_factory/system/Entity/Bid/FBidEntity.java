package com.cloud_factory.system.Entity.Bid;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDate;
import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_bid")
public class FBidEntity extends Model<FBidEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "fb_id", type = IdType.AUTO)
    private Long fbId;

    @TableField("fb_fid")
    private Long fbFid;

    @TableField("fb_state")
    private String fbState;

    @TableField("fb_finish_time")
    private LocalDate fbFinishTime;

    @TableField("fb_bid_price")
    private Double fbBidPrice;

    @TableField("fb_num")
    private Long fbNum;

    @TableField("fb_oid")
    private Long fbOid;

    @TableField(value = "gmt_created", fill= FieldFill.INSERT)
    private LocalDateTime gmtCreated;

    @TableField(value = "gmt_modified", fill= FieldFill.INSERT_UPDATE)
    private LocalDateTime gmtModified;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;
    @Override
    protected Serializable pkVal() {
        return this.fbId;
    }

}
