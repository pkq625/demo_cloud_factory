package com.cloud_factory.system.Controller.OrderController;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloud_factory.system.Entity.Bid.FBidEntity;
import com.cloud_factory.system.Entity.Order.FMorderEntity;
import com.cloud_factory.system.Service.Interf.Bid.FBidService;
import com.cloud_factory.system.Service.Interf.Order.FMorderService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class OrderController {
    @Resource
    private final FMorderService orderService;
    @Resource
    private final FBidService bidService;

    @RequestMapping("/system/order/allOrderInfo")
    @ResponseBody
    public List<FMorderEntity> getAllOrders(){
        return orderService.list();
    }

    @RequestMapping("/system/order/add")
    public String add(){
        return "/system/orderInfo/add";
    }

    @RequestMapping("/system/order/bidInfo")
    public String bidInfo(@RequestParam("oid")String oid, Model model){
        model.addAttribute("oid", oid);
        return "/system/orderInfo/bidInfo";
    }

    @RequestMapping("/system/order/checkAdd")
    @ResponseBody
    public String checkAdd(HttpServletRequest request, HttpSession session, RedirectAttributesModelMap model){
        Map<String, Object>param = new HashMap<>();
        param.put("orderCode", request.getParameter("ocode"));
        param.put("productId", Long.parseLong(String.valueOf(request.getParameter("pid"))));
        param.put("productNum", Long.parseLong(String.valueOf(request.getParameter("num"))));
        param.put("finish_date", request.getParameter("FinishTime"));
        param.put("bit_finish_date", request.getParameter("bidFinishTime"));
        param.put("receive_name", request.getParameter("rname"));
        param.put("receive_addr", request.getParameter("addr"));
        param.put("phone_num", request.getParameter("phoneNum"));
        param.put("result", "");
        orderService.createOrder(param);
        return String.valueOf(param.get("result"));
    }

    @RequestMapping("/system/order/getBidInfo")
    @ResponseBody
    public List<FBidEntity> getBidInfo(@RequestParam("oid")String oid){
        QueryWrapper<FBidEntity> wrapper = new QueryWrapper<>();
        wrapper.eq("fb_oid", Long.parseLong(oid));
        return bidService.list(wrapper);
    }

    @RequestMapping("/system/order/chooseBid")
    @ResponseBody
    public String getBidInfo(@RequestParam("bidId")Long bidId){
        Map<String, Object>param = new HashMap<>();
        param.put("bidId", bidId);
        param.put("result", "");
        orderService.pickBid(param);
        return String.valueOf(param.get("result"));
    }

    @RequestMapping("/system/order/getMorders")
    @ResponseBody
    public List<FMorderEntity> getMorders(@RequestParam("uid")Long uid){
        QueryWrapper<FMorderEntity> wrapper = new QueryWrapper<>();
        wrapper.eq("fmo_uid", uid);
        return orderService.list(wrapper);
    }
}
