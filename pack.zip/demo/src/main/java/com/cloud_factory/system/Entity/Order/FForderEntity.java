package com.cloud_factory.system.Entity.Order;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("f_forder")
public class FForderEntity extends Model<FForderEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "ffo_id", type = IdType.AUTO)
    private Long ffoId;

    @TableField("ffo_fid")
    private Long ffoFid;

    @TableField("ffo_oid")
    private Long ffoOid;

    @TableField(value = "gmt_created", fill= FieldFill.INSERT)
    private LocalDateTime gmtCreated;

    @TableField(value = "gmt_modified", fill=FieldFill.INSERT_UPDATE)
    private LocalDateTime gmtModified;

    @TableField("deleted")
    @TableLogic
    private Integer deleted;


    @Override
    protected Serializable pkVal() {
        return this.ffoId;
    }

}
