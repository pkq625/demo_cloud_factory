package com.cloud_factory.system.Service.Impl.Bid;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud_factory.system.Entity.Bid.FBidEntity;
import com.cloud_factory.system.Service.Interf.Bid.FBidService;
import com.cloud_factory.system.mappers.Bid.FBidMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Tery
 * @since 2021-07-18
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FBidServiceImpl extends ServiceImpl<FBidMapper, FBidEntity> implements FBidService {
    @Resource
    private final FBidMapper fBidMapper;
}
