package com.cloud_factory.common.myTreeStructure;

import java.util.ArrayDeque;
import java.util.LinkedList;
import java.util.Queue;

public class myTree <T>{
    private final myNode<T> rootNode;

    public myNode<T> getRootNode() {
        return rootNode;
    }

    public myTree(Long id, T item) {
        rootNode = new myNode<>(id, item);
        System.out.println("初始化头节点:"+item);
        rootNode.setParentNode(null);
        rootNode.setChildNodes(new LinkedList<>());
    }

    public myNode<T> bfs(T item){
        Queue<myNode<T>> q = new ArrayDeque<>();
        q.add(rootNode);

        while (!q.isEmpty()){
            myNode<T> curNode = q.poll();
            if (curNode.getInfo().equals(item)){
                System.out.println("找到:"+item);
                return curNode;
            }
            LinkedList<myNode<T>> childNodes = curNode.getChildNodes();
            System.out.println(curNode.getInfo());
            if (childNodes!=null){
                for (myNode<T> curItem : childNodes){
                    if (curItem.getInfo().equals(item)){
                        System.out.println("找到:"+item);
                        return curItem;
                    }else{
                        q.add(curItem);
                    }
                }
            }
        }
        return null;
    }

    public void dfs(T item){

    }

    public boolean addNode(Long id, T item, T parentInfo){
        if (null == bfs(item)){
            myNode<T> parentNode =  bfs(parentInfo);
            if (null != parentNode){
                myNode<T> tmyNode = new myNode<T>(id, item);
                tmyNode.setParentNode(parentNode);
                parentNode.getChildNodes().add(tmyNode);
                return true;
            }else {
                System.out.println("没找到父节点:"+parentInfo);
            }
        }else{
            System.out.println("'请勿重复添加:"+item);
        }
        return false;
    }

    public boolean deleteNode(T item){
        myNode<T> tmyNode = bfs(item);
        if (null != tmyNode){
            myNode<T> parentNode = tmyNode.getParentNode();
            tmyNode.setParentNode(null);
            parentNode.getChildNodes().remove(tmyNode);
            parentNode.getChildNodes().addAll(tmyNode.getChildNodes());
            return true;
        }
        return false;
    }

    public boolean editNode(T item, T newItem){
        myNode<T> tmyNode = bfs(item);
        if (null != tmyNode){
            tmyNode.setInfo(newItem);
            return true;
        }
        return false;
    }

}
