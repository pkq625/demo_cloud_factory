package com.cloud_factory.common.myAlgorithm;

import java.util.HashMap;
import java.util.Map;

public class UnionSet {
    private Map<Long, Long> arr = new HashMap<>();

    private Long findFather(Long curId){
        if (!arr.get(curId).equals(curId)){
            findFather(arr.get(curId));
        }
        return curId;
    }

    public void setArr(Map<Long, Long> arr) {
        this.arr = arr;
    }
}
