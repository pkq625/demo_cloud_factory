package com.cloud_factory.common.authentication;

import at.pollux.thymeleaf.shiro.dialect.ShiroDialect;
import com.cloud_factory.common.entity.Constants;
import com.cloud_factory.common.entity.Strings;
import com.cloud_factory.common.properties.CloudFactoryProperties;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.codec.Base64;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.CookieRememberMeManager;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.servlet.SimpleCookie;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Configuration(proxyBeanMethods = false)

public class ShiroConfig {
    /**
     * remember key
     * 生成方式：
     * String encryptKey = RandomStringUtils.randomAlphanumeric(15);
     * byte[] encryptKeyBytes = encryptKey.getBytes(StandardCharsets.UTF_8);
     * String rememberKey = Base64Utils.encodeToString(Arrays.copyOf(encryptKeyBytes, 16));
     */
    private final static String REMEMBER_ME_KEY = "M1RIN2FVNGt6T2lRU2VNAA==";
    @Resource
    private final CloudFactoryProperties cloudFactoryProperties;
    // shiro filter factory bean Step3
    @Bean(name = "shiroFilterFactoryBean")
    public ShiroFilterFactoryBean
    getShiroFilterFactoryBean(
            @Qualifier("getDefaultWebSecurityManager") DefaultWebSecurityManager securityManager
    ){
        ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();
        //设置security manager
        bean.setSecurityManager(securityManager);

        // 添加内置过滤器
        // anon：无需认证即可访问
        // authc：必须认证
        // user： 必须拥记住我功能
        // perms： 拥有对某个资源的权限才能访问
        // role： 拥有某个角色权限

        Map<String, String> filterChainDefinitionMap = new LinkedHashMap<>();
        //拦截
//        filterChainDefinitionMap.put("/user/*", "authc");

        //授权 未授权会跳转到401未授权页面
//        filterChainDefinitionMap.put("/user/add","perms[user:add]");

        bean.setFilterChainDefinitionMap(filterChainDefinitionMap);

        // 设置登录请求
        bean.setLoginUrl("/login");
        // 设置未授权请求
        bean.setUnauthorizedUrl("/unauthorized");
        return bean;
    }

    // default web security manager  Step2
    @Bean
    public DefaultWebSecurityManager getDefaultWebSecurityManager(@Qualifier("userRealm") UserRealm userRealm){
        DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
        //关联realm
        securityManager.setRealm(userRealm);
        // 配置 rememberMeCookie
        securityManager.setRememberMeManager(rememberMeManager());
        return securityManager;
    }

    // realm : Step1
    @Bean
    public UserRealm userRealm (){
        return new UserRealm();
    }

    // 整合shiroDialect：用来和thymeleaf整合
    @Bean
    public ShiroDialect getShiroDialect(){
        return new ShiroDialect();
    }

    /**
     * rememberMe cookie 效果是重开浏览器后无需重新登录
     *
     * @return SimpleCookie
     */
    private SimpleCookie rememberMeCookie() {
        // 设置 cookie 名称，对应 login.html 页面的 <input type="checkbox" name="rememberMe"/>
        SimpleCookie cookie = new SimpleCookie("rememberMe");
        // 设置 cookie 的过期时间，单位为秒
        cookie.setMaxAge((int) cloudFactoryProperties.getShiro().getCookieTimeout().getSeconds());
        return cookie;
    }

    /**
     * cookie管理对象
     *
     * @return CookieRememberMeManager
     */
    private CookieRememberMeManager rememberMeManager() {
        CookieRememberMeManager cookieRememberMeManager = new CookieRememberMeManager();
        cookieRememberMeManager.setCookie(rememberMeCookie());
        cookieRememberMeManager.setCipherKey(Base64.decode(REMEMBER_ME_KEY));
        return cookieRememberMeManager;
    }

    /**
     * 用于开启 Thymeleaf 中的 shiro 标签的使用Component
     *
     * @return ShiroDialect shiro 方言对象
     */
    @Bean
    public ShiroDialect shiroDialect() {
        return new ShiroDialect();
    }

}
