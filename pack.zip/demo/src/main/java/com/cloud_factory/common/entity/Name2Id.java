package com.cloud_factory.common.entity;

import java.util.HashMap;
import java.util.Map;

public class Name2Id {
    private static final Name2Id name2Id = new Name2Id();
    private final Map<String, Long> typeName2TypeId = new HashMap<>();





    private Name2Id(){
        typeName2TypeId.put("工厂主", 1L);
        typeName2TypeId.put("经销商", 2L);
    }




    public static Name2Id getInstance(){return name2Id;}


    public Map<String, Long> getTypeName2TypeId() {
        return typeName2TypeId;
    }
}
