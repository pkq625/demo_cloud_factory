package com.cloud_factory.common.entity;

import org.springframework.http.HttpStatus;

import java.util.HashMap;

public class CloudFactoryResponse extends HashMap<String, Object> {

    private static final long serialVersionUID = -8713837118340960775L;

    public CloudFactoryResponse code(HttpStatus status) {
        put("code", status.value());
        return this;
    }

    public CloudFactoryResponse message(String message) {
        put("message", message);
        return this;
    }

    public CloudFactoryResponse data(Object data) {
        put("data", data);
        return this;
    }

    public CloudFactoryResponse success() {
        code(HttpStatus.OK);
        return this;
    }

    public CloudFactoryResponse fail() {
        code(HttpStatus.INTERNAL_SERVER_ERROR);
        return this;
    }

    @Override
    public CloudFactoryResponse put(String key, Object value) {
        super.put(key, value);
        return this;
    }
}
