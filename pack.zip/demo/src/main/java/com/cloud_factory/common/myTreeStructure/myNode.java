package com.cloud_factory.common.myTreeStructure;

import java.util.LinkedList;
import java.util.Objects;

public class myNode <T>{
    private Long id;
    private T info;
    private myNode<T> parentNode;
    private LinkedList<myNode<T> > childNodes;

    public myNode() {
    }

    public myNode(Long id, T info) {
        this.id = id;
        this.info = info;
        childNodes = new LinkedList<>();
    }

    public myNode(T info, myNode<T> parentNode, LinkedList<myNode<T>> childNodes) {
        this.info = info;
        this.parentNode = parentNode;
        this.childNodes = childNodes;
    }

    public T getInfo() {
        return info;
    }

    public void setInfo(T info) {
        this.info = info;
    }

    public myNode<T> getParentNode() {
        return parentNode;
    }

    public void setParentNode(myNode<T> parentNode) {
        this.parentNode = parentNode;
    }

    public LinkedList<myNode<T>> getChildNodes() {
        return childNodes;
    }

    public void setChildNodes(LinkedList<myNode<T>> childNodes) {
        this.childNodes = childNodes;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "myNode{" +
                "info=" + info +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        myNode<?> myNode = (myNode<?>) o;
        return id.equals(myNode.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
