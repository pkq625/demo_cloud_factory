package com.cloud_factory.common.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class UserPermissions {
    public static UserPermissions getInstance() {
        return userPermissions;
    }
    private final static UserPermissions userPermissions = new UserPermissions();

    public List<String> getAdminPermissions() {
        return adminPermissions;
    }

    public List<String> getFactoryOwnerPermissions() {
        return factoryOwnerPermissions;
    }

    public List<String> getMercantilePermissions() {
        return mercantilePermissions;
    }

    private final List<String> adminPermissions;
    private final List<String> factoryOwnerPermissions;
    private final List<String> mercantilePermissions;
    private UserPermissions(){
        adminPermissions = new ArrayList<>();

        factoryOwnerPermissions = new ArrayList<>();

        mercantilePermissions = new ArrayList<>();

    }
}
