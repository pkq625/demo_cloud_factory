package com.cloud_factory.common.authentication;

import com.cloud_factory.common.utils.UserPermissions;
import com.cloud_factory.system.Entity.User.User;
import com.cloud_factory.system.Service.Interf.User.UserService;
import com.cloud_factory.system.Service.Interf.User.UserTypeService;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;

import javax.annotation.Resource;

@Slf4j
public class UserRealm extends AuthorizingRealm {
    @Resource
    UserService userService;
    @Resource
    UserTypeService userTypeService;


    //授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        System.out.println("执行了授权");

        // 拿到当前登录的对象
        Subject subject = SecurityUtils.getSubject();
        User currentUser = (User) subject.getPrincipal();

        // 添加用户权限
        // 获得用户的角色
        String roleName = userTypeService.getTypeName(currentUser.getFuTypeId());
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        info.addRole(roleName);
        if (roleName.equals("超级管理员"))
            info.addStringPermissions(UserPermissions.getInstance().getAdminPermissions());
        else if (roleName.equals("经销商"))
            info.addStringPermissions(UserPermissions.getInstance().getMercantilePermissions());
        else if (roleName.equals("工厂主"))
            info.addStringPermissions(UserPermissions.getInstance().getFactoryOwnerPermissions());
        return info;
//        return null;
    }

    //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        System.out.println("执行了认证");

        UsernamePasswordToken userToken = (UsernamePasswordToken) authenticationToken;

        // 密码认证由shiro完成
        User user = userService.findByName(userToken.getUsername());

        if (null == user){
            return null; // 抛出异常
        }


        Subject currentSubject = SecurityUtils.getSubject();
        Session session = currentSubject.getSession();
        session.setAttribute("loginUser", "user");


        // 把当前对象放到Principle这个参数中
        // 这里密码可以加密，md5加密,md5盐加密
        return new SimpleAuthenticationInfo(user,user.getFuPsw(),"");
    }

    
    @Override
    public void onLogout(PrincipalCollection principals) {
        super.onLogout(principals);
    }
}
