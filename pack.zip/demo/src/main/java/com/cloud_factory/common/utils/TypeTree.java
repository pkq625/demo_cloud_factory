package com.cloud_factory.common.utils;

import com.cloud_factory.common.myTreeStructure.myTree;

public class TypeTree {
    private static myTree<String> productTypeTree;

    public static myTree<String> getProductTypeTree() {
        return productTypeTree;
    }

    public static void setProductTypeTree(myTree<String> productTypeTree) {
        TypeTree.productTypeTree = productTypeTree;
    }

    private TypeTree (){}
}
