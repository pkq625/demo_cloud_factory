package com.cloud_factory.common.properties;

import cn.apiclub.captcha.Captcha;
import lombok.Data;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@SpringBootConfiguration(proxyBeanMethods = false)
@ConfigurationProperties(prefix = CloudFactoryProperties.PROPERTIES_PREFIX)
public class CloudFactoryProperties {

    public static final String PROPERTIES_PREFIX = "cloudfactory";

    private ShiroProperties shiro = new ShiroProperties();
    private SwaggerProperties swagger = new SwaggerProperties();
    /**
     * 批量插入提交commit数据量
     */
    private int maxBatchInsertNum = 1000;

    private Captcha code;
}
