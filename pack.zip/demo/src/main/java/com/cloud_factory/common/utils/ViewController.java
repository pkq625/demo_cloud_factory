package com.cloud_factory.common.utils;

import com.cloud_factory.common.controller.BaseController;
import com.cloud_factory.common.entity.Constants;
import com.cloud_factory.system.Entity.User.User;
import com.cloud_factory.system.Service.Interf.User.UserTypeService;
import com.cloud_factory.system.Service.Interf.User.UserService;
import lombok.RequiredArgsConstructor;
import org.apache.shiro.session.ExpiredSessionException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@Controller
@RequiredArgsConstructor
public class ViewController extends BaseController {
    @Resource
    private final UserService userService;
    @Resource
    private final UserTypeService userTypeService;

    @GetMapping("login")
    @ResponseBody
    public Object login(HttpServletRequest request) {
        if (Util.isAjaxRequest(request)) {
            throw new ExpiredSessionException();
        } else {
            ModelAndView mav = new ModelAndView();
            mav.setViewName(Util.view("login"));
            return mav;
        }
    }

    @GetMapping("unauthorized")
    public String unauthorized() {
        return Util.view("error/403");
    }


    @GetMapping("/")
    public String redirectIndex() {
        return "redirect:/login";
    }

    @GetMapping("index")
    public String index(Model model) {
        if (null == getCurrentUser()){
            return "redirect:/login";
        }
        System.out.println("当前用户名为："+getCurrentUser().getFuName());
        User principal = getCurrentUser();
        model.addAttribute("user", principal);
        model.addAttribute("uname", principal.getFuName());
        String roles = userTypeService.getTypeName(principal.getFuTypeId());
        System.out.println("当前用户角色is:"+roles);
        model.addAttribute("roles", roles);
        return "index";
    }

    @GetMapping(Constants.VIEW_PREFIX + "layout")
    public String layout() {
        return Util.view("layout");
    }

    @GetMapping(Constants.VIEW_PREFIX + "user/profile")
    public String userProfile() {
        return Util.view("system/user/userProfile");
    }

    @GetMapping(Constants.VIEW_PREFIX + "user/profile/update")
    public String profileUpdate() {
        return Util.view("system/user/profileUpdate");
    }

    @GetMapping(Constants.VIEW_PREFIX + "system/user")
//    @RequiresPermissions("user:view")
    public String systemUser() {
        return Util.view("system/user/user");
    }

    @GetMapping(Constants.VIEW_PREFIX + "system/user/detail/{username}")
    public String systemUserDetail(@PathVariable String username, Model model) {
        resolveUserModel(username, model);
        return Util.view("system/user/userDetail");
    }

    @GetMapping(Constants.VIEW_PREFIX + "system/user/update/{username}")
    public String systemUserUpdate(@PathVariable String username, Model model) {
        resolveUserModel(username, model);
        return Util.view("system/user/userUpdate");
    }

    @GetMapping(Constants.VIEW_PREFIX + "system/role")
    public String systemRole() {
        return Util.view("system/role/role");
    }

    @GetMapping(Constants.VIEW_PREFIX + "system/menu")
    public String systemMenu() {
        return Util.view("system/menu/menu");
    }

    @RequestMapping(Constants.VIEW_PREFIX + "index")
    public String pageIndex() {
        return Util.view("index");
    }

    @GetMapping(Constants.VIEW_PREFIX + "404")
    public String error404() {
        return Util.view("error/404");
    }

    @GetMapping(Constants.VIEW_PREFIX + "403")
    public String error403() {
        return Util.view("error/403");
    }

    @GetMapping(Constants.VIEW_PREFIX + "500")
    public String error500() {
        return Util.view("error/500");
    }

    private void resolveUserModel(String username, Model model) {
        User user = userService.findByName(username);
//        String deptIds = userTypeService.getTypeName(user.getFuTypeId());
//        user.setDeptIds(deptIds);
        model.addAttribute("user", user);
//        if (transform) {
//            String sex = user.getSex();
//            switch (sex) {
//                case User.SEX_MALE:
//                    user.setSex("男");
//                    break;
//                case User.SEX_FEMALE:
//                    user.setSex("女");
//                    break;
//                default:
//                    user.setSex("保密");
//                    break;
//            }
//        }
        if (user.getGmtModified() != null) {
            model.addAttribute("lastLoginTime", DateUtil.getDateFormat(user.getGmtModified(), DateUtil.FULL_TIME_SPLIT_PATTERN));
        }
    }


    @RequestMapping("/welcome")
    public String welcome(){
        return "/page/welcome";
    }

    @RequestMapping("/form")
    public String toForm(){
        return "/page/form";
    }

    @RequestMapping("/register")
    public String toRegister(){
        return "/register";
    }


    @RequestMapping("/system/user/profile")
    public String userProfiles(){
        return "/system/user/userInfo/usersProfiles";
    }

    @RequestMapping("/system/factory/factoryInfo")
    public String factoryInfo(){
        return "/system/factoryInfo/factoryInfo";
    }


    @RequestMapping("/system/facility/facilityInfo")
    public String facilityInfo(){
        return "/system/facilityInfo/facilityInfo";
    }

    @RequestMapping("/system/facilityType/facilityTypeInfo")
    public String facilityTypeInfo(){
        return "/system/facilityTypeInfo/facilityTypeInfo";
    }


    @RequestMapping("/system/product/productInfo")
    public String productInfo(){
        return "/system/productInfo/productInfo";
    }

    @RequestMapping("/system/productType/productTypeInfo")
    public String productTypeInfo(){
        return "/system/productTypeInfo/productTypeInfo";
    }


    @RequestMapping("/system/order/orderInfo")
    public String orderInfo(){
        return "/system/orderInfo/orderInfo";
    }


    @RequestMapping("/system/generatePower/generatePowerInfo")
    public String generationPower(){
        return "/system/generatePowerInfo/generatePowerInfo";
    }


    @RequestMapping("/system/schedule/schedu cxzZZleInfo")
    public String schedule(){
        return "/system/scheduleInfo/scheduleInfo";
    }


    @RequestMapping("/system/factoryOrder/factoryOrderInfo")
    public String factoryOrder(){
        return "/system/factoryOrderInfo/factoryOrderInfo";
    }

    @RequestMapping("/system/rentFacility/rentFacilityInfo")
    public String rent(){
        return "/system/rentFacilityInfo/rentFacilityInfo";
    }
}
