package com.cloud_factory.common.entity;

public interface ImageType {

    /**
     * gif类型
     */
    String GIF = "gif";
    /**
     * png类型
     */
    String PNG = "png";
}
